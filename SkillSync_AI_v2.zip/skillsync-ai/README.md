# SkillSync AI

**Workforce skill intelligence.** SkillSync shows where a team's skills fall short of what their roles need, works out what to learn first, and turns that into a week-by-week plan. It also groups people who share a gap into training cohorts, pairs them with in-house mentors, and flags skills that only one person on the team knows well.

React · Spring Boot · MySQL / H2 · Python (Flask) recommendation engine · optional Claude LLM narratives

---

## What it does

| Area | Features |
|---|---|
| **Overview** | KPIs (employees, assessments, open and critical gaps), team readiness ring, team gap chart, "needs attention" list, readiness by department |
| **Employees** | Search, filter and sort profiles; add or edit people; **role templates** fill in a role's required skills automatically |
| **Employee profile** | Radar chart, assessments you can edit inline (0–5 level picker), add or remove skills, **personal AI learning plan** |
| **AI learning plan** | Priority score (0–100) for each gap with a reason, **prerequisite-aware learning path**, courses matched to the learner's current level, effort estimate, **week-by-week schedule** based on the hours per week you set (slider) |
| **Skill matrix** | Heatmap of every person × every skill (gap view or proficiency view), department filter, **CSV import/export**, demo reset |
| **AI team insights** | Team briefing, **group training cohorts**, **mentor matching**, **expertise risk** (no expert, or only one), skill coverage table |
| **Quality** | Dark mode, mobile layout with bottom nav, toasts, confirmation dialogs, loading skeletons, keyboard and screen-reader support, live status of the API and AI engine |

## How the AI engine works

All the numbers come from a deterministic engine in `python-ai/engine.py`, so you can explain and test every one of them.

**Priority score** for each gap:

```
score = 100 × (0.50 × gap/5            # how far below target
             + 0.30 × importance       # business weight from the skill catalogue
             + 0.20 × unlock_value)    # share of the person's other gaps this skill unblocks
```
Labels: Critical ≥ 65 · High ≥ 45 · Medium ≥ 30 · Low.

**Learning path.** The engine runs a topological sort over skill prerequisites (for example, Spring Boot needs Java and SQL). Among the skills that are ready to learn, the highest score goes first.

**Effort.** Each step up a level costs 15% more than the previous one (`hours_per_level × (1 + 0.15 × level)`). The total is then packed into weeks at the learner's hours per week.

**Course matching.** Each course covers a band of levels. Only the courses that overlap the learner's range (current to target) are suggested, so nobody at level 4 gets sent back to "Fundamentals".

**Team insights.** If two or more people share a gap, they form a cohort. Mentors must be at level 4 or above and at least at the mentee's target, take no more than 3 mentees each, and are matched within the same department when possible. Risks flag skills with no expert and skills with only one expert.

**Readiness** is the same everywhere (dashboard, profile and engine):
`Σ min(current, required) ÷ Σ required × 100`. Being ahead on one skill can't hide a gap on another.

**Optional LLM narrative.** Set `ANTHROPIC_API_KEY` and Claude rewrites the engine's results as a short coaching summary. It is told to use only the supplied facts. With no key, or if the call fails, a rule-based summary is used, so the demo always works. The UI labels which kind of summary you're seeing.

## Quick start

### Option A: one command (Docker)
```bash
docker compose up --build
```
Open http://localhost:3000. This runs MySQL, the AI engine, the API and the UI behind nginx.
To turn on LLM summaries: `ANTHROPIC_API_KEY=sk-... docker compose up --build`.

### Option B: local dev, no MySQL needed
The backend's default profile uses an **in-memory H2 database** and seeds an 8-person demo team.

Requirements: Java 17+, Maven 3.9+, Node 20.19+ (or 22.12+), Python 3.10+.

```bash
./start-dev.sh          # macOS / Linux
start-dev.bat           # Windows
```
Or start each service yourself in three terminals:
```bash
# 1. AI engine (port 5001)
cd python-ai && python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt && python app.py

# 2. API (port 8080)
cd backend && mvn spring-boot:run

# 3. UI (port 5173). Vite proxies /api to :8080, so there are no CORS issues.
cd frontend && npm install && npm run dev
```

### Using MySQL instead of H2
```bash
cd backend
DB_PASSWORD=yourpassword mvn spring-boot:run -Dspring-boot.run.profiles=mysql
```
Optional overrides: `DB_URL`, `DB_USERNAME`. The database and tables are created automatically. `database/schema.sql` documents the schema.

## Configuration

| Variable | Service | Default | Purpose |
|---|---|---|---|
| `SPRING_PROFILES_ACTIVE` | backend | `h2` | `h2` (demo) or `mysql` |
| `DB_URL` / `DB_USERNAME` / `DB_PASSWORD` | backend | local MySQL / `root` / empty | MySQL connection |
| `PYTHON_AI_URL` | backend | `http://localhost:5001` | AI engine location |
| `CORS_ORIGINS` | backend | localhost:5173, 4173, 3000 | Allowed browser origins |
| `DEMO_SEED` / `DEMO_RESET_ENABLED` | backend | `true` / `true` | Demo data and the reset button (turn off in production) |
| `ANTHROPIC_API_KEY` | python-ai | none | Enables LLM narratives |
| `SKILLSYNC_LLM_MODEL` | python-ai | `claude-sonnet-5-5` | Model for narratives |
| `VITE_API_URL` | frontend | `/api` | Only if the UI is served away from the API |

## API

| Method | Path | Description |
|---|---|---|
| GET | `/api/employees?search=&department=` | Employee summaries (readiness, gaps, top gaps) |
| POST | `/api/employees` | Create (`applyRoleTemplate: true` pre-fills role skills) |
| GET / PUT / DELETE | `/api/employees/{id}` | Detail, update, delete |
| POST | `/api/employees/{id}/skills` | Add an assessment (409 if the skill already exists) |
| PUT / DELETE | `/api/skills/{id}` | Update or delete an assessment |
| GET | `/api/skills` | Every assessment as a flat list |
| POST | `/api/employees/{id}/recommendations?hoursPerWeek=6` | Personal AI learning plan |
| POST | `/api/insights/team` | Cohorts, mentors, risks, team summary |
| GET | `/api/dashboard` · `/api/matrix` · `/api/roles` | Aggregates, heatmap, role templates |
| GET / POST | `/api/export/csv` · `/api/import/csv` | CSV round-trip (multipart or `text/csv`) |
| POST | `/api/demo/reset` | Restore the demo team |
| GET | `/api/health` | API and AI engine status |

Errors always come back in the same shape: `{ timestamp, status, error, message, fieldErrors }`.

The AI engine's own endpoints are `GET /health`, `GET /catalog`, `POST /recommend` and `POST /team-insights`. The backend always builds the engine's input from the database, never from data the browser sends.

**CSV format**, see `database/sample-import.csv`:
```
employeeName,email,department,jobRole,skillName,currentLevel,requiredLevel
```
Import is an upsert: employees are matched by name, and skills by employee plus skill name. Invalid rows are skipped and reported with their line numbers. Export protects against spreadsheet formula injection.

## Tests
```bash
cd python-ai && python -m pytest -q     # engine: scoring, prerequisites, scheduling, cohorts, mentors, HTTP
cd backend && mvn test                  # API: CRUD, validation, 404/409/503, dashboard, matrix, CSV
```

## Project structure
```
skillsync-ai/
├── backend/            Spring Boot 3.5, Java 17
│   └── src/main/java/com/skillsync/
│       ├── controller/  Employee, Skill, Insights, Data (CSV / demo)
│       ├── service/     EmployeeService, AiClient, CsvService, RoleTemplates, Readiness
│       ├── model/       Employee 1─* SkillAssessment
│       ├── dto/         request/response records (entities never leave the API)
│       ├── exception/   unified error handling
│       └── config/      CORS, demo seeder
├── python-ai/          Flask engine: catalog.py, engine.py, llm.py, app.py, tests/
├── frontend/           React 19 + Vite + Recharts: views/, components/, api.js
├── database/           schema.sql, sample-import.csv
├── docker-compose.yml
└── start-dev.sh / start-dev.bat
```

## Responsible use
SkillSync supports development decisions. Readiness scores and recommendations are estimates based on self-reported or manager-assessed levels. Don't use them as the only basis for hiring, promotion, performance or termination decisions.
