-- SkillSync AI - MySQL 8.x schema (reference).
-- Hibernate creates/updates these tables automatically (ddl-auto=update),
-- so running this file is optional. It documents the data model.

CREATE DATABASE IF NOT EXISTS skillsync_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE skillsync_db;

CREATE TABLE IF NOT EXISTS employees (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(120),
  department  VARCHAR(60)  NOT NULL,
  job_role    VARCHAR(60)  NOT NULL,
  created_at  TIMESTAMP(6) NOT NULL
);

CREATE TABLE IF NOT EXISTS skill_assessments (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  employee_id     BIGINT      NOT NULL,
  skill_name      VARCHAR(60) NOT NULL,
  current_level   INT         NOT NULL CHECK (current_level BETWEEN 0 AND 5),
  required_level  INT         NOT NULL CHECK (required_level BETWEEN 1 AND 5),
  updated_at      TIMESTAMP(6) NOT NULL,
  CONSTRAINT uk_employee_skill UNIQUE (employee_id, skill_name),
  CONSTRAINT fk_assessment_employee FOREIGN KEY (employee_id) REFERENCES employees (id) ON DELETE CASCADE
);
