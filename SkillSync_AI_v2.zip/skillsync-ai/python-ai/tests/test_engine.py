import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.pop("ANTHROPIC_API_KEY", None)

import engine  # noqa: E402
from app import app  # noqa: E402

AARAV = [
    {"skillName": "Java", "currentLevel": 4, "requiredLevel": 5},
    {"skillName": "SQL", "currentLevel": 2, "requiredLevel": 5},
    {"skillName": "Spring Boot", "currentLevel": 1, "requiredLevel": 4},
    {"skillName": "React", "currentLevel": 3, "requiredLevel": 3},
    {"skillName": "Python", "currentLevel": 2, "requiredLevel": 3},
]


def test_readiness_formula():
    # (4 + 2 + 1 + 3 + 2) / (5 + 5 + 4 + 3 + 3) = 12 / 20
    assert engine.readiness(engine.normalise_skills(AARAV)) == 60


def test_prerequisites_come_first_in_learning_path():
    result = engine.recommend(AARAV)
    path = result["learningPath"]
    assert path.index("SQL") < path.index("Spring Boot")
    assert path.index("Java") < path.index("Spring Boot")
    assert "React" not in path  # no gap


def test_recommendations_are_ranked_and_labelled():
    result = engine.recommend(AARAV)
    scores = [r["priorityScore"] for r in result["recommendations"]]
    assert scores == sorted(scores, reverse=True)
    assert {r["priority"] for r in result["recommendations"]} <= {"Critical", "High", "Medium", "Low"}
    sql = next(r for r in result["recommendations"] if r["skillName"] == "SQL")
    assert "Spring Boot" in sql["unlocks"]


def test_weekly_plan_respects_capacity_and_totals():
    result = engine.recommend(AARAV, hours_per_week=5)
    assert all(w["hours"] <= 5.01 for w in result["weeklyPlan"])
    planned = sum(i["hours"] for w in result["weeklyPlan"] for i in w["items"])
    assert planned == pytest.approx(result["totalEstimatedHours"], abs=0.6)


def test_courses_match_level_band():
    courses = engine.select_courses("SQL", 2, 5)
    titles = [c["title"] for c in courses]
    assert not any("Fundamentals" in t for t in titles)
    assert any("Advanced SQL" in t for t in titles)


def test_unknown_skill_gets_generic_course():
    result = engine.recommend([{"skillName": "Kotlin", "currentLevel": 0, "requiredLevel": 3}])
    assert result["recommendations"][0]["courses"][0]["format"] == "Personalised"


def test_no_gaps():
    result = engine.recommend([{"skillName": "Java", "currentLevel": 5, "requiredLevel": 4}])
    assert result["totalGaps"] == 0
    assert result["strengths"] == ["Java"]
    assert result["readinessScore"] == 100


def test_invalid_input_rejected():
    with pytest.raises(engine.ValidationError):
        engine.normalise_skills([{"currentLevel": 1}])
    with pytest.raises(engine.ValidationError):
        engine.normalise_skills("nope")


def test_team_insights_cohorts_mentors_and_risks():
    team = [
        {"name": "Aarav", "department": "Engineering", "skills": AARAV},
        {"name": "Meera", "department": "Engineering", "skills": [
            {"skillName": "SQL", "currentLevel": 5, "requiredLevel": 4},
            {"skillName": "Spring Boot", "currentLevel": 2, "requiredLevel": 4},
        ]},
        {"name": "Kabir", "department": "Data", "skills": [
            {"skillName": "SQL", "currentLevel": 1, "requiredLevel": 4},
            {"skillName": "Spring Boot", "currentLevel": 4, "requiredLevel": 4},
        ]},
    ]
    r = engine.team_insights(team)
    cohort_skills = {c["skillName"] for c in r["cohorts"]}
    assert "SQL" in cohort_skills and "Spring Boot" in cohort_skills
    sql_pairs = [p for p in r["mentorPairs"] if p["skillName"] == "SQL"]
    assert {p["mentor"] for p in sql_pairs} == {"Meera"}
    assert all(p["mentor"] != p["mentee"] for p in r["mentorPairs"])
    assert 0 <= r["teamReadiness"] <= 100


def test_http_endpoints():
    client = app.test_client()
    assert client.get("/health").json["status"] == "ok"
    res = client.post("/recommend", json={"skills": AARAV, "employee": {"name": "Aarav"}})
    assert res.status_code == 200
    assert res.json["summary"]["source"] == "rules"
    assert "Aarav" in res.json["summary"]["text"]
    assert client.post("/recommend", data="x", content_type="text/plain").status_code == 400
    assert client.post("/team-insights", json={"employees": []}).status_code == 200
    assert len(client.get("/catalog").json["skills"]) >= 8
