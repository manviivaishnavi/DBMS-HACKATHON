"""SkillSync recommendation engine.

Pure functions, no Flask imports, so they are easy to unit test.

Scoring model
-------------
Every skill gap gets a priority score from 0-100:

    score = 100 * (0.50 * gap_severity      # how far below target (gap / 5)
                 + 0.30 * importance        # business weight from the catalogue
                 + 0.20 * unlock_value)     # how many other gaps this skill unblocks

Learning paths respect prerequisites (topological sort, highest score first
among skills that are ready to learn) and are packed into a week-by-week plan
based on the learner's available hours per week.

Readiness everywhere is   sum(min(current, required)) / sum(required) * 100
so the dashboard, employee pages and the engine always agree.
"""

from __future__ import annotations

import math
from collections import defaultdict

from catalog import LEVEL_NAMES, canonical_name, skill_info

MAX_LEVEL = 5
PROVIDER = "SkillSync Academy"


# --------------------------------------------------------------------------- #
# Input normalisation
# --------------------------------------------------------------------------- #
class ValidationError(ValueError):
    pass


def _to_int(value, field, low, high):
    try:
        number = int(float(value))
    except (TypeError, ValueError):
        raise ValidationError(f"'{field}' must be a number between {low} and {high}")
    return max(low, min(high, number))


def normalise_skills(raw_skills) -> list[dict]:
    if not isinstance(raw_skills, list):
        raise ValidationError("'skills' must be a list")
    merged: dict[str, dict] = {}
    for index, item in enumerate(raw_skills):
        if not isinstance(item, dict):
            raise ValidationError(f"skills[{index}] must be an object")
        name = str(item.get("skillName", "")).strip()
        if not name:
            raise ValidationError(f"skills[{index}].skillName is required")
        name = canonical_name(name)
        current = _to_int(item.get("currentLevel", 0), "currentLevel", 0, MAX_LEVEL)
        required = _to_int(item.get("requiredLevel", 1), "requiredLevel", 1, MAX_LEVEL)
        # If the same skill appears twice keep the strictest target.
        if name in merged:
            merged[name]["requiredLevel"] = max(merged[name]["requiredLevel"], required)
            merged[name]["currentLevel"] = max(merged[name]["currentLevel"], current)
        else:
            merged[name] = {"skillName": name, "currentLevel": current, "requiredLevel": required}
    return list(merged.values())


def readiness(skills: list[dict]) -> int:
    required = sum(s["requiredLevel"] for s in skills)
    if not required:
        return 0
    achieved = sum(min(s["currentLevel"], s["requiredLevel"]) for s in skills)
    return round(achieved / required * 100)


# --------------------------------------------------------------------------- #
# Individual recommendations
# --------------------------------------------------------------------------- #
def estimate_hours(skill_name: str, current: int, required: int) -> int:
    """Higher levels take longer: each step costs 15% more than the last."""
    per_level = skill_info(skill_name)["hours_per_level"]
    return round(sum(per_level * (1 + 0.15 * level) for level in range(current, required)))


def select_courses(skill_name: str, current: int, required: int) -> list[dict]:
    info = skill_info(skill_name)
    chosen = [
        c for c in info["courses"]
        if c["min"] < required and c["max"] > current
    ]
    if not chosen:
        chosen = [{
            "title": f"{skill_name} Skill Development Plan",
            "min": current, "max": required,
            "duration_hours": max(3, estimate_hours(skill_name, current, required) // 2),
            "format": "Personalised",
        }]
    return [{
        "title": c["title"],
        "provider": PROVIDER,
        "format": c["format"],
        "durationHours": c["duration_hours"],
        "fromLevel": max(current, c["min"]),
        "toLevel": min(required, c["max"]),
    } for c in chosen]


def priority_label(score: float) -> str:
    if score >= 65:
        return "Critical"
    if score >= 45:
        return "High"
    if score >= 30:
        return "Medium"
    return "Low"


def _rationale(gap_item: dict, unlocks: list[str]) -> str:
    parts = [
        f"{LEVEL_NAMES[gap_item['currentLevel']]} → {LEVEL_NAMES[gap_item['requiredLevel']]}"
        f" ({gap_item['gap']} level{'s' if gap_item['gap'] != 1 else ''} to close)"
    ]
    importance = skill_info(gap_item["skillName"])["importance"]
    if importance >= 0.8:
        parts.append("core skill for the role")
    if unlocks:
        parts.append("unlocks " + ", ".join(unlocks))
    if gap_item["blockedBy"]:
        parts.append("start after " + ", ".join(gap_item["blockedBy"]))
    text = "; ".join(parts)
    return text[:1].upper() + text[1:] + "."


def learning_order(items: list[dict]) -> list[str]:
    """Kahn's topological sort; among ready skills pick the highest score."""
    names = {i["skillName"] for i in items}
    score = {i["skillName"]: i["priorityScore"] for i in items}
    deps = {i["skillName"]: set(i["blockedBy"]) & names for i in items}
    order: list[str] = []
    while deps:
        ready = [n for n, d in deps.items() if not d]
        if not ready:  # cycle in the catalogue: fall back to score order
            ready = list(deps)
        nxt = max(ready, key=lambda n: (score[n], n))
        order.append(nxt)
        deps.pop(nxt)
        for d in deps.values():
            d.discard(nxt)
    return order


def weekly_plan(items_by_name: dict, order: list[str], hours_per_week: float, max_weeks: int = 52) -> list[dict]:
    units = []
    for name in order:
        item = items_by_name[name]
        total_course = sum(c["durationHours"] for c in item["courses"]) or 1
        for course in item["courses"]:
            # Scale course hours so that a skill's modules add up to its estimate
            hours = item["estimatedHours"] * course["durationHours"] / total_course
            units.append({"skillName": name, "course": course["title"], "hours": hours})

    weeks: list[dict] = []
    current = {"week": 1, "hours": 0.0, "items": []}
    for unit in units:
        remaining = unit["hours"]
        while remaining > 0.01:
            capacity = hours_per_week - current["hours"]
            take = min(capacity, remaining)
            current["items"].append({"skillName": unit["skillName"], "course": unit["course"], "hours": round(take, 1)})
            current["hours"] += take
            remaining -= take
            if current["hours"] >= hours_per_week - 0.01:
                weeks.append(current)
                if len(weeks) >= max_weeks:
                    return _finish_weeks(weeks)
                current = {"week": len(weeks) + 1, "hours": 0.0, "items": []}
    if current["items"]:
        weeks.append(current)
    return _finish_weeks(weeks)


def _finish_weeks(weeks):
    for w in weeks:
        w["hours"] = round(w["hours"], 1)
        # merge consecutive fragments of the same course within a week
        merged = []
        for it in w["items"]:
            if merged and merged[-1]["course"] == it["course"]:
                merged[-1]["hours"] = round(merged[-1]["hours"] + it["hours"], 1)
            else:
                merged.append(dict(it))
        w["items"] = merged
    return weeks


def recommend(skills: list[dict], hours_per_week: float = 6, employee: dict | None = None) -> dict:
    skills = normalise_skills(skills)
    hours_per_week = max(1.0, min(40.0, float(hours_per_week or 6)))

    gaps = [dict(s, gap=s["requiredLevel"] - s["currentLevel"]) for s in skills if s["requiredLevel"] > s["currentLevel"]]
    gap_names = {g["skillName"] for g in gaps}

    # Which gap skills does each skill unblock?
    unlocks = defaultdict(list)
    for g in gaps:
        for pre in skill_info(g["skillName"])["prerequisites"]:
            pre = canonical_name(pre)
            if pre in gap_names:
                unlocks[pre].append(g["skillName"])

    denom = max(1, len(gaps) - 1)
    items = []
    for g in gaps:
        info = skill_info(g["skillName"])
        unlock_value = min(1.0, len(unlocks[g["skillName"]]) / denom)
        score = 100 * (0.5 * g["gap"] / MAX_LEVEL + 0.3 * info["importance"] + 0.2 * unlock_value)
        item = {
            **g,
            "category": info["category"],
            "priorityScore": round(score),
            "priority": priority_label(score),
            "blockedBy": [canonical_name(p) for p in info["prerequisites"] if canonical_name(p) in gap_names],
            "unlocks": unlocks[g["skillName"]],
            "estimatedHours": estimate_hours(g["skillName"], g["currentLevel"], g["requiredLevel"]),
            "courses": select_courses(g["skillName"], g["currentLevel"], g["requiredLevel"]),
            "resource": info["resource"],
        }
        item["rationale"] = _rationale(item, item["unlocks"])
        items.append(item)

    order = learning_order(items)
    by_name = {i["skillName"]: i for i in items}
    ranked = sorted(items, key=lambda i: (-i["priorityScore"], i["skillName"]))
    plan = weekly_plan(by_name, order, hours_per_week)
    total_hours = sum(i["estimatedHours"] for i in items)

    strengths = sorted(
        [s["skillName"] for s in skills if s["currentLevel"] >= s["requiredLevel"] and s["currentLevel"] >= 4]
    )
    result = {
        "employee": employee or None,
        "readinessScore": readiness(skills),
        "projectedReadiness": 100 if skills else 0,
        "totalGaps": len(items),
        "totalEstimatedHours": total_hours,
        "hoursPerWeek": hours_per_week,
        "estimatedWeeks": math.ceil(total_hours / hours_per_week) if total_hours else 0,
        "recommendations": ranked,
        "learningPath": order,
        "weeklyPlan": plan,
        "strengths": strengths,
    }
    result["summary"] = individual_summary(result)
    return result


def individual_summary(result: dict) -> str:
    who = (result.get("employee") or {}).get("name") or "This employee"
    recs = result["recommendations"]
    if not recs:
        return f"{who} meets every target level. Consider stretch goals or mentoring others" + (
            f" in {', '.join(result['strengths'][:3])}." if result["strengths"] else "."
        )
    top = recs[0]
    critical = [r["skillName"] for r in recs if r["priority"] in ("Critical", "High")]
    text = (
        f"{who} is {result['readinessScore']}% ready for their role with {len(recs)} skill gap"
        f"{'s' if len(recs) != 1 else ''}. "
        f"The biggest lever is {top['skillName']} (priority {top['priorityScore']}/100). "
    )
    if critical:
        text += f"Focus first on {', '.join(critical[:3])}. "
    text += (
        f"Following the suggested path ({' → '.join(result['learningPath'])}) takes about "
        f"{result['totalEstimatedHours']} hours, roughly {result['estimatedWeeks']} week"
        f"{'s' if result['estimatedWeeks'] != 1 else ''} at {result['hoursPerWeek']:g} h/week."
    )
    if result["strengths"]:
        text += f" Strengths to build on: {', '.join(result['strengths'][:3])}."
    return text


# --------------------------------------------------------------------------- #
# Team insights
# --------------------------------------------------------------------------- #
def team_insights(employees: list[dict]) -> dict:
    if not isinstance(employees, list):
        raise ValidationError("'employees' must be a list")

    people = []
    for idx, e in enumerate(employees):
        if not isinstance(e, dict):
            raise ValidationError(f"employees[{idx}] must be an object")
        skills = normalise_skills(e.get("skills", []))
        people.append({
            "id": e.get("id"),
            "name": str(e.get("name") or f"Employee {idx + 1}"),
            "jobRole": e.get("jobRole") or "",
            "department": e.get("department") or "Unassigned",
            "skills": {s["skillName"]: s for s in skills},
            "readiness": readiness(skills),
        })

    all_skills = sorted({name for p in people for name in p["skills"]})
    skill_stats = []
    for name in all_skills:
        holders = [p for p in people if name in p["skills"]]
        levels = [p["skills"][name] for p in holders]
        gap_people = [p["name"] for p in holders if p["skills"][name]["currentLevel"] < p["skills"][name]["requiredLevel"]]
        experts = [p["name"] for p in holders if p["skills"][name]["currentLevel"] >= 4]
        skill_stats.append({
            "skillName": name,
            "category": skill_info(name)["category"],
            "tracked": len(holders),
            "avgCurrent": round(sum(l["currentLevel"] for l in levels) / len(levels), 2),
            "avgRequired": round(sum(l["requiredLevel"] for l in levels) / len(levels), 2),
            "avgGap": round(sum(max(0, l["requiredLevel"] - l["currentLevel"]) for l in levels) / len(levels), 2),
            "peopleWithGap": gap_people,
            "experts": experts,
        })
    skill_stats.sort(key=lambda s: (-s["avgGap"], s["skillName"]))

    # Cohorts: the same gap shared by 2+ people -> run one group session
    cohorts = []
    for s in skill_stats:
        if len(s["peopleWithGap"]) >= 2:
            learners = [p for p in people if p["name"] in s["peopleWithGap"]]
            low = min(p["skills"][s["skillName"]]["currentLevel"] for p in learners)
            high = max(p["skills"][s["skillName"]]["requiredLevel"] for p in learners)
            course = select_courses(s["skillName"], low, high)[0]
            cohorts.append({
                "skillName": s["skillName"],
                "learners": s["peopleWithGap"],
                "size": len(s["peopleWithGap"]),
                "avgGap": s["avgGap"],
                "suggestedCourse": course["title"],
                "format": course["format"],
                "durationHours": course["durationHours"],
            })
    cohorts.sort(key=lambda c: (-c["size"], -c["avgGap"]))

    # Mentor matching: expert (>=4 and >= mentee target) <-> mentee with gap >= 2
    mentor_load = defaultdict(int)
    pairs = []
    for s in skill_stats:
        name = s["skillName"]
        mentees = sorted(
            [p for p in people if name in p["skills"]
             and p["skills"][name]["requiredLevel"] - p["skills"][name]["currentLevel"] >= 2],
            key=lambda p: p["skills"][name]["currentLevel"],
        )
        for mentee in mentees:
            target = mentee["skills"][name]["requiredLevel"]
            candidates = [
                p for p in people
                if p is not mentee and name in p["skills"]
                and p["skills"][name]["currentLevel"] >= max(4, target)
                and mentor_load[p["name"]] < 3
            ]
            if not candidates:
                continue
            mentor = max(candidates, key=lambda p: (
                p["department"] == mentee["department"],
                p["skills"][name]["currentLevel"],
                -mentor_load[p["name"]],
            ))
            mentor_load[mentor["name"]] += 1
            pairs.append({
                "skillName": name,
                "mentor": mentor["name"],
                "mentorLevel": mentor["skills"][name]["currentLevel"],
                "mentee": mentee["name"],
                "menteeLevel": mentee["skills"][name]["currentLevel"],
                "menteeTarget": target,
                "sameDepartment": mentor["department"] == mentee["department"],
            })

    # Risks
    risks = []
    for s in skill_stats:
        demand = [p for p in people if s["skillName"] in p["skills"] and p["skills"][s["skillName"]]["requiredLevel"] >= 4]
        if not s["experts"] and demand:
            risks.append({
                "type": "No in-house expert",
                "severity": "High",
                "skillName": s["skillName"],
                "detail": f"{len(demand)} {'person needs' if len(demand) == 1 else 'people need'} {s['skillName']} at level 4+, "
                          f"but nobody on the team is there yet. "
                          f"Consider external training or hiring.",
            })
        elif len(s["experts"]) == 1 and s["tracked"] >= 3:
            risks.append({
                "type": "Knowledge concentration",
                "severity": "Medium",
                "skillName": s["skillName"],
                "detail": f"Only {s['experts'][0]} is at level 4+ in {s['skillName']}. "
                          f"Pair them with a backup to reduce bus-factor risk.",
            })
    risks.sort(key=lambda r: (r["severity"] != "High", r["skillName"]))

    departments = defaultdict(list)
    for p in people:
        departments[p["department"]].append(p)
    dept_stats = sorted([
        {
            "department": d,
            "employees": len(ps),
            "readiness": readiness([s for p in ps for s in p["skills"].values()]),
        } for d, ps in departments.items()
    ], key=lambda d: d["readiness"])

    all_records = [s for p in people for s in p["skills"].values()]
    at_risk = sorted(
        [{"name": p["name"], "jobRole": p["jobRole"], "readiness": p["readiness"]} for p in people if p["readiness"] < 60],
        key=lambda p: p["readiness"],
    )

    result = {
        "teamReadiness": readiness(all_records),
        "employees": len(people),
        "skills": skill_stats,
        "cohorts": cohorts,
        "mentorPairs": pairs,
        "risks": risks,
        "departments": dept_stats,
        "employeesNeedingSupport": at_risk,
    }
    result["summary"] = team_summary(result)
    return result


def team_summary(r: dict) -> str:
    if not r["employees"]:
        return "No employees yet. Add people and skill assessments to unlock team insights."
    text = f"The team of {r['employees']} is {r['teamReadiness']}% ready overall. "
    widest = [s for s in r["skills"] if s["avgGap"] > 0][:2]
    if widest:
        text += "Widest gaps: " + ", ".join(f"{s['skillName']} (avg {s['avgGap']:g} levels)" for s in widest) + ". "
    if r["cohorts"]:
        c = r["cohorts"][0]
        text += f"A group {c['skillName']} session would cover {c['size']} people at once. "
    if r["mentorPairs"]:
        n = len(r["mentorPairs"])
        text += f"{n} internal mentoring pair{'s' if n != 1 else ''} can close gaps without external spend. "
    high = [x for x in r["risks"] if x["severity"] == "High"]
    if high:
        text += f"Hiring or external training is advised for {', '.join(x['skillName'] for x in high[:3])}."
    return text.strip()
