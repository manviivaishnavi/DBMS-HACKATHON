"""SkillSync AI - recommendation microservice (Flask)."""

import os

from flask import Flask, jsonify, request
from flask_cors import CORS

import engine
import llm
from catalog import LEVEL_NAMES, SKILLS

app = Flask(__name__)
CORS(app, origins=os.environ.get("CORS_ORIGINS", "*").split(","))


@app.errorhandler(engine.ValidationError)
def handle_validation(err):
    return jsonify({"error": "Bad Request", "message": str(err)}), 400


@app.errorhandler(404)
def handle_404(_):
    return jsonify({"error": "Not Found", "message": "Unknown endpoint"}), 404


@app.errorhandler(500)
def handle_500(err):  # pragma: no cover
    return jsonify({"error": "Internal Server Error", "message": "Recommendation engine failed"}), 500


def _body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise engine.ValidationError("Request body must be a JSON object")
    return data


@app.get("/health")
def health():
    return jsonify({
        "status": "ok",
        "service": "SkillSync AI recommendation engine",
        "version": "2.0.0",
        "llmEnabled": llm.enabled(),
        "llmModel": llm.MODEL if llm.enabled() else None,
        "catalogSkills": len(SKILLS),
    })


@app.get("/catalog")
def catalog():
    return jsonify({
        "levels": LEVEL_NAMES,
        "skills": [
            {
                "name": name,
                "category": info["category"],
                "importance": info["importance"],
                "prerequisites": info["prerequisites"],
                "resource": info["resource"],
                "courses": [{"title": c["title"], "fromLevel": c["min"], "toLevel": c["max"],
                             "durationHours": c["duration_hours"], "format": c["format"]} for c in info["courses"]],
            }
            for name, info in SKILLS.items()
        ],
    })


@app.post("/recommend")
def recommend():
    data = _body()
    result = engine.recommend(
        data.get("skills", []),
        hours_per_week=data.get("hoursPerWeek", 6),
        employee=data.get("employee"),
    )
    result["summary"] = llm.narrate("individual", result, result["summary"])
    return jsonify(result)


@app.post("/team-insights")
def team_insights():
    data = _body()
    result = engine.team_insights(data.get("employees", []))
    result["summary"] = llm.narrate("team", result, result["summary"])
    return jsonify(result)


if __name__ == "__main__":
    app.run(
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "5001")),
        debug=os.environ.get("FLASK_DEBUG", "0") == "1",
    )
