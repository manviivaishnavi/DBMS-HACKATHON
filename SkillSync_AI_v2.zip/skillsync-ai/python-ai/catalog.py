"""Skill knowledge base used by the SkillSync recommendation engine.

Each skill carries:
  category       - grouping used for insights
  importance     - 0..1 business weight (how much a gap in this skill hurts)
  prerequisites  - skills that should be learned first (drives the learning path)
  hours_per_level- rough effort to move up one proficiency level
  courses        - learning modules, each covering a level band [min_level, max_level)

Course titles are internal catalogue modules. `resource` links point only to
official, long-lived documentation so nothing here is a made-up URL.
"""

LEVEL_NAMES = {
    0: "None",
    1: "Awareness",
    2: "Beginner",
    3: "Practitioner",
    4: "Advanced",
    5: "Expert",
}

SKILLS = {
    "Java": {
        "category": "Backend",
        "importance": 0.9,
        "prerequisites": [],
        "hours_per_level": 10,
        "resource": "https://dev.java/learn/",
        "courses": [
            {"title": "Java Foundations: Syntax, OOP & Collections", "min": 0, "max": 2, "duration_hours": 8, "format": "Self-paced"},
            {"title": "Modern Java: Streams, Records & Concurrency", "min": 2, "max": 4, "duration_hours": 10, "format": "Workshop"},
            {"title": "JVM Performance & Design Patterns", "min": 4, "max": 5, "duration_hours": 8, "format": "Mentored project"},
        ],
    },
    "Spring Boot": {
        "category": "Backend",
        "importance": 0.85,
        "prerequisites": ["Java", "SQL"],
        "hours_per_level": 9,
        "resource": "https://spring.io/guides",
        "courses": [
            {"title": "Spring Boot REST API Development", "min": 0, "max": 2, "duration_hours": 6, "format": "Self-paced"},
            {"title": "Spring Data JPA, Validation & Testing", "min": 2, "max": 4, "duration_hours": 8, "format": "Workshop"},
            {"title": "Production Spring: Security, Observability, Scaling", "min": 4, "max": 5, "duration_hours": 10, "format": "Mentored project"},
        ],
    },
    "SQL": {
        "category": "Data",
        "importance": 0.8,
        "prerequisites": [],
        "hours_per_level": 6,
        "resource": "https://dev.mysql.com/doc/refman/8.4/en/tutorial.html",
        "courses": [
            {"title": "SQL Fundamentals: SELECT, JOIN, GROUP BY", "min": 0, "max": 2, "duration_hours": 4, "format": "Self-paced"},
            {"title": "Advanced SQL: Window Functions & CTEs", "min": 2, "max": 4, "duration_hours": 5, "format": "Workshop"},
            {"title": "Query Tuning & Index Design", "min": 4, "max": 5, "duration_hours": 6, "format": "Mentored project"},
        ],
    },
    "Python": {
        "category": "Backend",
        "importance": 0.75,
        "prerequisites": [],
        "hours_per_level": 7,
        "resource": "https://docs.python.org/3/tutorial/",
        "courses": [
            {"title": "Python Programming Essentials", "min": 0, "max": 2, "duration_hours": 5, "format": "Self-paced"},
            {"title": "Idiomatic Python: Typing, Testing & Packaging", "min": 2, "max": 4, "duration_hours": 7, "format": "Workshop"},
            {"title": "Python at Scale: Async, Profiling, APIs", "min": 4, "max": 5, "duration_hours": 8, "format": "Mentored project"},
        ],
    },
    "React": {
        "category": "Frontend",
        "importance": 0.8,
        "prerequisites": ["JavaScript"],
        "hours_per_level": 8,
        "resource": "https://react.dev/learn",
        "courses": [
            {"title": "React Fundamentals: Components, Props & Hooks", "min": 0, "max": 2, "duration_hours": 6, "format": "Self-paced"},
            {"title": "State Management, Data Fetching & Testing", "min": 2, "max": 4, "duration_hours": 8, "format": "Workshop"},
            {"title": "React Performance & Architecture", "min": 4, "max": 5, "duration_hours": 8, "format": "Mentored project"},
        ],
    },
    "JavaScript": {
        "category": "Frontend",
        "importance": 0.75,
        "prerequisites": [],
        "hours_per_level": 7,
        "resource": "https://developer.mozilla.org/en-US/docs/Learn_web_development",
        "courses": [
            {"title": "JavaScript Essentials & the DOM", "min": 0, "max": 2, "duration_hours": 6, "format": "Self-paced"},
            {"title": "Async JavaScript, Modules & Tooling", "min": 2, "max": 4, "duration_hours": 6, "format": "Workshop"},
            {"title": "JavaScript Internals & Performance", "min": 4, "max": 5, "duration_hours": 6, "format": "Mentored project"},
        ],
    },
    "Data Analysis": {
        "category": "Data",
        "importance": 0.7,
        "prerequisites": ["SQL", "Python"],
        "hours_per_level": 8,
        "resource": "https://pandas.pydata.org/docs/getting_started/index.html",
        "courses": [
            {"title": "Data Analysis with pandas", "min": 0, "max": 2, "duration_hours": 6, "format": "Self-paced"},
            {"title": "Statistics & Visual Storytelling", "min": 2, "max": 4, "duration_hours": 8, "format": "Workshop"},
            {"title": "Experiment Design & Forecasting", "min": 4, "max": 5, "duration_hours": 8, "format": "Mentored project"},
        ],
    },
    "Cloud & DevOps": {
        "category": "Platform",
        "importance": 0.7,
        "prerequisites": [],
        "hours_per_level": 9,
        "resource": "https://docs.docker.com/get-started/",
        "courses": [
            {"title": "Containers & CI Basics", "min": 0, "max": 2, "duration_hours": 6, "format": "Self-paced"},
            {"title": "Deploying Services: Docker Compose to Kubernetes", "min": 2, "max": 4, "duration_hours": 9, "format": "Workshop"},
            {"title": "Reliability Engineering & Incident Response", "min": 4, "max": 5, "duration_hours": 8, "format": "Mentored project"},
        ],
    },
    "Communication": {
        "category": "Professional",
        "importance": 0.65,
        "prerequisites": [],
        "hours_per_level": 5,
        "resource": None,
        "courses": [
            {"title": "Workplace Communication Skills", "min": 0, "max": 2, "duration_hours": 3, "format": "Live session"},
            {"title": "Writing Clear Technical Docs & Updates", "min": 2, "max": 4, "duration_hours": 4, "format": "Workshop"},
            {"title": "Influencing & Presenting to Stakeholders", "min": 4, "max": 5, "duration_hours": 4, "format": "Coaching"},
        ],
    },
    "Leadership": {
        "category": "Professional",
        "importance": 0.6,
        "prerequisites": ["Communication"],
        "hours_per_level": 6,
        "resource": None,
        "courses": [
            {"title": "Foundations of Team Leadership", "min": 0, "max": 2, "duration_hours": 4, "format": "Live session"},
            {"title": "Feedback, Delegation & 1:1s", "min": 2, "max": 4, "duration_hours": 5, "format": "Workshop"},
            {"title": "Leading Through Change", "min": 4, "max": 5, "duration_hours": 5, "format": "Coaching"},
        ],
    },
}

DEFAULT_SKILL = {
    "category": "General",
    "importance": 0.5,
    "prerequisites": [],
    "hours_per_level": 6,
    "resource": None,
    "courses": [],
}


def skill_info(name: str) -> dict:
    """Return catalogue metadata for a skill, matching case-insensitively."""
    if name in SKILLS:
        return SKILLS[name]
    lowered = name.lower()
    for key, value in SKILLS.items():
        if key.lower() == lowered:
            return value
    return DEFAULT_SKILL


def canonical_name(name: str) -> str:
    lowered = name.lower()
    for key in SKILLS:
        if key.lower() == lowered:
            return key
    return name
