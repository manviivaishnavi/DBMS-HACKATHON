"""Optional LLM narrative layer.

If ANTHROPIC_API_KEY is set, the engine's structured output is handed to Claude
to write a short coaching-style summary. The numbers always come from the
deterministic engine; the LLM only rewrites them in plain language. If the key
is missing or the call fails for any reason, the rule-based summary is used,
so the demo never breaks.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

API_URL = "https://api.anthropic.com/v1/messages"
MODEL = os.environ.get("SKILLSYNC_LLM_MODEL", "claude-sonnet-5-5")
TIMEOUT = float(os.environ.get("SKILLSYNC_LLM_TIMEOUT", "20"))


def enabled() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def _call(prompt: str, max_tokens: int = 400) -> str | None:
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return None
    body = json.dumps({
        "model": MODEL,
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()
    req = urllib.request.Request(API_URL, data=body, method="POST", headers={
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
    })
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            data = json.loads(resp.read())
        text = "".join(block.get("text", "") for block in data.get("content", []) if block.get("type") == "text")
        return text.strip() or None
    except (urllib.error.URLError, TimeoutError, ValueError, KeyError) as exc:  # pragma: no cover - network
        print(f"[llm] falling back to rule-based summary: {exc}")
        return None


def narrate(kind: str, payload: dict, fallback: str) -> dict:
    """Return {"text": ..., "source": "llm"|"rules"}."""
    if not enabled():
        return {"text": fallback, "source": "rules"}
    slim = {k: v for k, v in payload.items() if k not in ("weeklyPlan", "skills")}
    prompt = (
        "You are a supportive L&D coach inside an HR skills tool. Using ONLY the facts in the JSON below, "
        f"write a {'personal development' if kind == 'individual' else 'team capability'} summary in 3-4 sentences "
        "of plain prose (no lists, no headings, no markdown). Mention the most important gaps, the recommended "
        "first step, and one encouraging strength or opportunity. Do not invent numbers, names or courses. "
        "Do not make hiring, firing or performance judgements.\n\n"
        + json.dumps(slim, default=str)[:12000]
    )
    text = _call(prompt)
    return {"text": text, "source": "llm"} if text else {"text": fallback, "source": "rules"}
