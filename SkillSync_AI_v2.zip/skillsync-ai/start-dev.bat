@echo off
REM Starts the whole stack on Windows (H2 demo database, no MySQL needed).
REM Opens three terminal windows. Close them to stop.
set ROOT=%~dp0
start "SkillSync AI engine" cmd /k "cd /d %ROOT%python-ai && (if not exist .venv python -m venv .venv) && .venv\Scripts\activate && pip install -q -r requirements.txt && python app.py"
start "SkillSync API" cmd /k "cd /d %ROOT%backend && mvn spring-boot:run"
start "SkillSync UI" cmd /k "cd /d %ROOT%frontend && (if not exist node_modules npm install) && npm run dev"
echo Frontend will be at http://localhost:5173 once all three windows finish starting.
