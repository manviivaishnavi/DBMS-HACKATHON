package com.skillsync;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(properties = {
        "python.ai.base-url=http://localhost:59999",   // nothing listens here
        "python.ai.timeout-ms=500"
})
class SkillSyncApiTests {

    @Autowired
    MockMvc mvc;

    @Autowired
    ObjectMapper json;

    @BeforeEach
    void reset() throws Exception {
        mvc.perform(post("/api/demo/reset")).andExpect(status().isOk());
    }

    private JsonNode body(org.springframework.test.web.servlet.ResultActions r) throws Exception {
        return json.readTree(r.andReturn().getResponse().getContentAsString());
    }

    @Test
    void seedsDemoTeam() throws Exception {
        mvc.perform(get("/api/employees"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(8));
    }

    @Test
    void createEmployeeWithRoleTemplate() throws Exception {
        JsonNode created = body(mvc.perform(post("/api/employees").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Test Person\",\"department\":\"QA\",\"jobRole\":\"Data Analyst\",\"applyRoleTemplate\":true}"))
                .andExpect(status().isCreated()));
        assertThat(created.get("skills").size()).isEqualTo(4);
        assertThat(created.get("readiness").asInt()).isZero();
    }

    @Test
    void validationErrorsAreReadable() throws Exception {
        mvc.perform(post("/api/employees").contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.name").exists());
    }

    @Test
    void addUpdateDeleteSkill() throws Exception {
        long id = body(mvc.perform(post("/api/employees").contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Skill Tester\",\"jobRole\":\"Java Developer\"}"))).get("id").asLong();

        String skill = "{\"skillName\":\"Kotlin\",\"currentLevel\":1,\"requiredLevel\":4}";
        long skillId = body(mvc.perform(post("/api/employees/" + id + "/skills")
                .contentType(MediaType.APPLICATION_JSON).content(skill))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.gap").value(3))
                .andExpect(jsonPath("$.critical").value(true))).get("id").asLong();

        // duplicate -> 409
        mvc.perform(post("/api/employees/" + id + "/skills").contentType(MediaType.APPLICATION_JSON).content(skill))
                .andExpect(status().isConflict());

        mvc.perform(put("/api/skills/" + skillId).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"skillName\":\"Kotlin\",\"currentLevel\":4,\"requiredLevel\":4}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.gap").value(0));

        mvc.perform(get("/api/employees/" + id)).andExpect(jsonPath("$.readiness").value(100));

        mvc.perform(delete("/api/skills/" + skillId)).andExpect(status().isNoContent());
        mvc.perform(get("/api/employees/" + id)).andExpect(jsonPath("$.skills.length()").value(0));
    }

    @Test
    void levelsOutOfRangeRejected() throws Exception {
        mvc.perform(post("/api/employees/1/skills").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"skillName\":\"Java\",\"currentLevel\":7,\"requiredLevel\":4}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void dashboardAndMatrix() throws Exception {
        JsonNode dash = body(mvc.perform(get("/api/dashboard")).andExpect(status().isOk()));
        assertThat(dash.get("employees").asInt()).isEqualTo(8);
        assertThat(dash.get("readiness").asInt()).isBetween(1, 99);
        assertThat(dash.get("skillBreakdown").size()).isGreaterThan(3);

        mvc.perform(get("/api/matrix"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rows.length()").value(8));
    }

    @Test
    void missingEmployeeIs404() throws Exception {
        mvc.perform(get("/api/employees/99999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Employee 99999 not found"));
    }

    @Test
    void csvRoundTrip() throws Exception {
        String csv = mvc.perform(get("/api/export/csv")).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertThat(csv).startsWith("employeeName,email,department,jobRole,skillName,currentLevel,requiredLevel");

        String upload = "employeeName,department,jobRole,skillName,currentLevel,requiredLevel\n"
                + "New Hire,Data,Data Analyst,SQL,1,5\n"
                + "New Hire,Data,Data Analyst,Python,9,4\n"       // invalid level
                + "Aarav Sharma,Engineering,Java Developer,SQL,4,4\n";  // update existing
        JsonNode result = body(mvc.perform(post("/api/import/csv").contentType("text/csv").content(upload))
                .andExpect(status().isOk()));
        assertThat(result.get("employeesCreated").asInt()).isEqualTo(1);
        assertThat(result.get("skillsCreated").asInt()).isEqualTo(1);
        assertThat(result.get("skillsUpdated").asInt()).isEqualTo(1);
        assertThat(result.get("rowsSkipped").asInt()).isEqualTo(1);
    }

    @Test
    void aiDownReturns503WithHelpfulMessage() throws Exception {
        long id = body(mvc.perform(get("/api/employees"))).get(0).get("id").asLong();
        mvc.perform(post("/api/employees/" + id + "/recommendations"))
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.message").exists());
    }
}
