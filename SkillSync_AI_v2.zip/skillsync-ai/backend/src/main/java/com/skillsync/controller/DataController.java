package com.skillsync.controller;

import com.skillsync.config.DemoDataSeeder;
import com.skillsync.dto.Dtos.ImportResult;
import com.skillsync.exception.ApiExceptions.BadRequestException;
import com.skillsync.service.CsvService;
import com.skillsync.service.EmployeeService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class DataController {

    private final CsvService csv;
    private final EmployeeService employees;
    private final DemoDataSeeder seeder;
    private final boolean resetEnabled;

    public DataController(CsvService csv, EmployeeService employees, DemoDataSeeder seeder,
                          @Value("${app.demo.reset-enabled:false}") boolean resetEnabled) {
        this.csv = csv;
        this.employees = employees;
        this.seeder = seeder;
        this.resetEnabled = resetEnabled;
    }

    @GetMapping(value = "/export/csv", produces = "text/csv")
    public ResponseEntity<byte[]> exportCsv() {
        String filename = "skillsync-export-" + LocalDate.now() + ".csv";
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .contentType(new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(csv.export().getBytes(StandardCharsets.UTF_8));
    }

    @PostMapping(value = "/import/csv", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ImportResult importFile(@RequestParam("file") MultipartFile file) {
        try {
            return csv.importCsv(new String(file.getBytes(), StandardCharsets.UTF_8));
        } catch (IOException ex) {
            throw new BadRequestException("Could not read the uploaded file");
        }
    }

    @PostMapping(value = "/import/csv", consumes = {"text/csv", MediaType.TEXT_PLAIN_VALUE})
    public ImportResult importText(@RequestBody String body) {
        return csv.importCsv(body);
    }

    /** Wipes all data and restores the demo team. Disable with DEMO_RESET_ENABLED=false. */
    @PostMapping("/demo/reset")
    public Map<String, Object> reset() {
        if (!resetEnabled) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Demo reset is disabled");
        }
        employees.deleteAll();
        seeder.seed();
        return Map.of("status", "reset", "employees", employees.list(null, null).size());
    }
}
