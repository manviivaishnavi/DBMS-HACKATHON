package com.skillsync.service;

import com.skillsync.dto.Dtos.ImportResult;
import com.skillsync.exception.ApiExceptions.BadRequestException;
import com.skillsync.model.Employee;
import com.skillsync.model.SkillAssessment;
import com.skillsync.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * CSV import/export. Format (header required, order free):
 * <pre>employeeName,email,department,jobRole,skillName,currentLevel,requiredLevel</pre>
 * Import is an upsert: employees are matched by name, skills by employee + skill name.
 */
@Service
public class CsvService {

    static final List<String> HEADER = List.of(
            "employeeName", "email", "department", "jobRole", "skillName", "currentLevel", "requiredLevel");
    private static final int MAX_ERRORS = 20;

    private final EmployeeRepository employees;

    public CsvService(EmployeeRepository employees) {
        this.employees = employees;
    }

    @Transactional(readOnly = true)
    public String export() {
        StringBuilder sb = new StringBuilder(String.join(",", HEADER)).append('\n');
        for (Employee e : employees.findAllWithSkills()) {
            if (e.getSkills().isEmpty()) {
                sb.append(row(e.getName(), e.getEmail(), e.getDepartment(), e.getJobRole(), "", "", "")).append('\n');
            }
            for (SkillAssessment s : e.getSkills()) {
                sb.append(row(e.getName(), e.getEmail(), e.getDepartment(), e.getJobRole(), s.getSkillName(),
                        String.valueOf(s.getCurrentLevel()), String.valueOf(s.getRequiredLevel()))).append('\n');
            }
        }
        return sb.toString();
    }

    @Transactional
    public ImportResult importCsv(String content) {
        if (content == null || content.isBlank()) {
            throw new BadRequestException("CSV file is empty");
        }
        List<List<String>> rows = parse(content.replace("﻿", ""));
        if (rows.isEmpty()) {
            throw new BadRequestException("CSV file is empty");
        }
        Map<String, Integer> col = new HashMap<>();
        List<String> header = rows.get(0);
        for (int i = 0; i < header.size(); i++) {
            col.put(header.get(i).trim().toLowerCase(Locale.ROOT), i);
        }
        for (String required : List.of("employeename", "jobrole")) {
            if (!col.containsKey(required)) {
                throw new BadRequestException("CSV header must include: " + String.join(",", HEADER));
            }
        }

        Map<String, Employee> cache = new HashMap<>();
        employees.findAllWithSkills().forEach(e -> cache.putIfAbsent(e.getName().toLowerCase(Locale.ROOT), e));

        int created = 0, skillsCreated = 0, skillsUpdated = 0, skipped = 0;
        List<String> errors = new ArrayList<>();

        for (int r = 1; r < rows.size(); r++) {
            List<String> row = rows.get(r);
            if (row.stream().allMatch(String::isBlank)) {
                continue;
            }
            int line = r + 1;
            try {
                String name = req(get(row, col, "employeename"), "employeeName");
                String role = req(get(row, col, "jobrole"), "jobRole");
                String dept = Optional.ofNullable(get(row, col, "department")).filter(s -> !s.isBlank()).orElse("General");
                String email = Optional.ofNullable(get(row, col, "email")).filter(s -> !s.isBlank()).orElse(null);

                Employee e = cache.get(name.toLowerCase(Locale.ROOT));
                if (e == null) {
                    e = employees.save(new Employee(name, email, dept, role));
                    cache.put(name.toLowerCase(Locale.ROOT), e);
                    created++;
                }

                String skill = get(row, col, "skillname");
                if (skill == null || skill.isBlank()) {
                    continue;
                }
                int current = level(get(row, col, "currentlevel"), 0, "currentLevel");
                int target = level(get(row, col, "requiredlevel"), 1, "requiredLevel");
                Optional<SkillAssessment> existing = e.getSkills().stream()
                        .filter(s -> s.getSkillName().equalsIgnoreCase(skill.trim())).findFirst();
                if (existing.isPresent()) {
                    existing.get().setCurrentLevel(current);
                    existing.get().setRequiredLevel(target);
                    skillsUpdated++;
                } else {
                    e.addSkill(skill.trim(), current, target);
                    skillsCreated++;
                }
            } catch (BadRequestException ex) {
                skipped++;
                if (errors.size() < MAX_ERRORS) {
                    errors.add("Line " + line + ": " + ex.getMessage());
                }
            }
        }
        employees.flush();
        return new ImportResult(created, skillsCreated, skillsUpdated, skipped, errors);
    }

    // ----------------------------------------------------------------- helpers

    private static String get(List<String> row, Map<String, Integer> col, String key) {
        Integer i = col.get(key);
        return i == null || i >= row.size() ? null : row.get(i).trim();
    }

    private static String req(String v, String field) {
        if (v == null || v.isBlank()) {
            throw new BadRequestException(field + " is required");
        }
        if (v.length() > 100) {
            throw new BadRequestException(field + " is too long");
        }
        return v;
    }

    private static int level(String v, int min, String field) {
        try {
            int n = Integer.parseInt(v == null ? "" : v.trim());
            if (n < min || n > 5) {
                throw new BadRequestException(field + " must be between " + min + " and 5");
            }
            return n;
        } catch (NumberFormatException ex) {
            throw new BadRequestException(field + " must be a whole number");
        }
    }

    private static String row(String... values) {
        List<String> out = new ArrayList<>();
        for (String v : values) {
            out.add(escape(v));
        }
        return String.join(",", out);
    }

    static String escape(String v) {
        if (v == null) {
            return "";
        }
        // Neutralise spreadsheet formula injection
        String safe = !v.isEmpty() && "=+-@".indexOf(v.charAt(0)) >= 0 ? "'" + v : v;
        if (safe.contains(",") || safe.contains("\"") || safe.contains("\n")) {
            return "\"" + safe.replace("\"", "\"\"") + "\"";
        }
        return safe;
    }

    /** Minimal RFC 4180 parser: quoted fields, escaped quotes, CRLF. */
    static List<List<String>> parse(String text) {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
                        field.append('"');
                        i++;
                    } else {
                        quoted = false;
                    }
                } else {
                    field.append(c);
                }
            } else if (c == '"') {
                quoted = true;
            } else if (c == ',') {
                row.add(field.toString());
                field.setLength(0);
            } else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') {
                    i++;
                }
                row.add(field.toString());
                field.setLength(0);
                rows.add(row);
                row = new ArrayList<>();
            } else {
                field.append(c);
            }
        }
        if (field.length() > 0 || !row.isEmpty()) {
            row.add(field.toString());
            rows.add(row);
        }
        return rows;
    }
}
