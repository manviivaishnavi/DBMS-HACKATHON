package com.skillsync.service;

import com.skillsync.dto.Dtos.RoleTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeSet;

/** Required proficiency profiles per job role, used to pre-fill new employees. */
@Component
public class RoleTemplates {

    private final Map<String, RoleTemplate> templates = new LinkedHashMap<>();

    public RoleTemplates() {
        add("Java Developer", "Builds and maintains JVM back-end services",
                "Java", 5, "Spring Boot", 4, "SQL", 4, "Cloud & DevOps", 2, "Communication", 3);
        add("Frontend Developer", "Builds accessible, fast user interfaces",
                "JavaScript", 5, "React", 5, "Communication", 3, "Cloud & DevOps", 2);
        add("Software Engineer", "Full-stack product engineer",
                "Java", 4, "Spring Boot", 3, "JavaScript", 4, "React", 4, "SQL", 4, "Communication", 3);
        add("Python Developer", "Builds Python services and automation",
                "Python", 5, "SQL", 4, "Cloud & DevOps", 3, "Communication", 3);
        add("Data Analyst", "Turns data into decisions",
                "SQL", 5, "Python", 4, "Data Analysis", 5, "Communication", 4);
        add("DevOps Engineer", "Owns delivery pipelines and infrastructure",
                "Cloud & DevOps", 5, "Python", 3, "Java", 2, "Communication", 3);
        add("Engineering Manager", "Leads and grows an engineering team",
                "Leadership", 5, "Communication", 5, "Java", 3, "Cloud & DevOps", 2);
    }

    private void add(String role, String description, Object... pairs) {
        Map<String, Integer> required = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) {
            required.put((String) pairs[i], (Integer) pairs[i + 1]);
        }
        templates.put(role, new RoleTemplate(role, description, Collections.unmodifiableMap(required)));
    }

    public List<RoleTemplate> all() {
        return new ArrayList<>(templates.values());
    }

    public Optional<RoleTemplate> find(String role) {
        if (role == null) {
            return Optional.empty();
        }
        return templates.values().stream().filter(t -> t.role().equalsIgnoreCase(role.trim())).findFirst();
    }

    /** Every skill named in any template, alphabetically. */
    public List<String> knownSkills() {
        TreeSet<String> skills = new TreeSet<>();
        templates.values().forEach(t -> skills.addAll(t.requiredSkills().keySet()));
        return new ArrayList<>(skills);
    }
}
