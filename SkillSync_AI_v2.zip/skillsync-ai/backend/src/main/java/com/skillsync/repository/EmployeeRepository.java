package com.skillsync.repository;

import com.skillsync.model.Employee;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    /** Loads every employee with their skills in one query (avoids N+1). */
    @EntityGraph(attributePaths = "skills")
    @Query("select distinct e from Employee e order by e.name")
    List<Employee> findAllWithSkills();

    @EntityGraph(attributePaths = "skills")
    @Query("select e from Employee e where e.id = :id")
    Optional<Employee> findWithSkillsById(@Param("id") Long id);

    Optional<Employee> findFirstByNameIgnoreCase(String name);
}
