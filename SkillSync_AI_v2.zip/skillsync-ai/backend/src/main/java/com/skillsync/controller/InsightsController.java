package com.skillsync.controller;

import com.skillsync.dto.Dtos.DashboardStats;
import com.skillsync.dto.Dtos.SkillMatrix;
import com.skillsync.service.AiClient;
import com.skillsync.service.EmployeeService;
import com.skillsync.service.RoleTemplates;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class InsightsController {

    private final EmployeeService service;
    private final RoleTemplates roles;
    private final AiClient ai;

    public InsightsController(EmployeeService service, RoleTemplates roles, AiClient ai) {
        this.service = service;
        this.roles = roles;
        this.ai = ai;
    }

    @GetMapping("/dashboard")
    public DashboardStats dashboard() {
        return service.dashboard();
    }

    @GetMapping("/matrix")
    public SkillMatrix matrix() {
        return service.matrix();
    }

    @GetMapping("/roles")
    public Map<String, Object> roles() {
        return Map.of("roles", roles.all(), "skills", roles.knownSkills());
    }

    /** Cohorts, mentor pairs, expertise risks and a narrative summary for the whole team. */
    @PostMapping("/insights/team")
    public Map<String, Object> teamInsights() {
        return ai.teamInsights(service.allWithSkills());
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("backend", "up");
        body.put("ai", ai.health());
        return body;
    }
}
