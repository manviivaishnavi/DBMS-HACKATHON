package com.skillsync.service;

import com.skillsync.dto.Dtos.DashboardStats;
import com.skillsync.dto.Dtos.DepartmentStat;
import com.skillsync.dto.Dtos.EmployeeDetail;
import com.skillsync.dto.Dtos.EmployeeRequest;
import com.skillsync.dto.Dtos.EmployeeSummary;
import com.skillsync.dto.Dtos.MatrixCell;
import com.skillsync.dto.Dtos.MatrixRow;
import com.skillsync.dto.Dtos.SkillGapStat;
import com.skillsync.dto.Dtos.SkillMatrix;
import com.skillsync.dto.Dtos.SkillRequest;
import com.skillsync.dto.Dtos.SkillView;
import com.skillsync.exception.ApiExceptions.BadRequestException;
import com.skillsync.exception.ApiExceptions.ConflictException;
import com.skillsync.exception.ApiExceptions.NotFoundException;
import com.skillsync.model.Employee;
import com.skillsync.model.SkillAssessment;
import com.skillsync.repository.EmployeeRepository;
import com.skillsync.repository.SkillAssessmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class EmployeeService {

    private static final String DEFAULT_DEPARTMENT = "General";

    private final EmployeeRepository employees;
    private final SkillAssessmentRepository assessments;
    private final RoleTemplates roleTemplates;

    public EmployeeService(EmployeeRepository employees, SkillAssessmentRepository assessments,
                           RoleTemplates roleTemplates) {
        this.employees = employees;
        this.assessments = assessments;
        this.roleTemplates = roleTemplates;
    }

    // ------------------------------------------------------------------ queries

    public List<EmployeeSummary> list(String search, String department) {
        String q = search == null ? "" : search.trim().toLowerCase(Locale.ROOT);
        return employees.findAllWithSkills().stream()
                .filter(e -> department == null || department.isBlank() || e.getDepartment().equalsIgnoreCase(department))
                .filter(e -> q.isEmpty()
                        || e.getName().toLowerCase(Locale.ROOT).contains(q)
                        || e.getJobRole().toLowerCase(Locale.ROOT).contains(q)
                        || e.getSkills().stream().anyMatch(s -> s.getSkillName().toLowerCase(Locale.ROOT).contains(q)))
                .map(this::toSummary)
                .toList();
    }

    public EmployeeDetail get(Long id) {
        return toDetail(load(id));
    }

    /** Raw entities for building AI payloads. */
    public Employee loadWithSkills(Long id) {
        return load(id);
    }

    public List<Employee> allWithSkills() {
        return employees.findAllWithSkills();
    }

    public List<SkillView> allSkills() {
        return employees.findAllWithSkills().stream()
                .flatMap(e -> e.getSkills().stream())
                .map(this::toView)
                .toList();
    }

    public DashboardStats dashboard() {
        List<Employee> all = employees.findAllWithSkills();
        List<SkillAssessment> records = all.stream().flatMap(e -> e.getSkills().stream()).toList();

        long gaps = records.stream().filter(s -> s.gap() > 0).count();
        long critical = records.stream().filter(SkillAssessment::isCritical).count();

        Map<String, List<SkillAssessment>> bySkill = records.stream()
                .collect(Collectors.groupingBy(SkillAssessment::getSkillName, TreeMap::new, Collectors.toList()));
        List<SkillGapStat> breakdown = bySkill.entrySet().stream()
                .map(en -> {
                    List<SkillAssessment> list = en.getValue();
                    return new SkillGapStat(en.getKey(), list.size(),
                            round1(list.stream().mapToInt(SkillAssessment::getCurrentLevel).average().orElse(0)),
                            round1(list.stream().mapToInt(SkillAssessment::getRequiredLevel).average().orElse(0)),
                            round1(list.stream().mapToInt(SkillAssessment::gap).average().orElse(0)),
                            (int) list.stream().filter(s -> s.gap() > 0).count());
                })
                .sorted(Comparator.comparingDouble(SkillGapStat::avgGap).reversed()
                        .thenComparing(SkillGapStat::skillName))
                .toList();

        Map<String, List<Employee>> byDept = all.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment, TreeMap::new, Collectors.toList()));
        List<DepartmentStat> departments = byDept.entrySet().stream()
                .map(en -> {
                    List<SkillAssessment> deptSkills = en.getValue().stream().flatMap(e -> e.getSkills().stream()).toList();
                    return new DepartmentStat(en.getKey(), en.getValue().size(), Readiness.of(deptSkills),
                            (int) deptSkills.stream().filter(s -> s.gap() > 0).count());
                })
                .sorted(Comparator.comparingInt(DepartmentStat::readiness))
                .toList();

        List<EmployeeSummary> needsAttention = all.stream()
                .map(this::toSummary)
                .filter(s -> s.gapCount() > 0)
                .sorted(Comparator.comparingInt(EmployeeSummary::readiness)
                        .thenComparing(EmployeeSummary::criticalGaps, Comparator.reverseOrder()))
                .limit(5)
                .toList();

        return new DashboardStats(all.size(), records.size(), gaps, critical, Readiness.of(records),
                breakdown, departments, needsAttention);
    }

    public SkillMatrix matrix() {
        List<Employee> all = employees.findAllWithSkills();
        TreeSet<String> skillNames = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        all.forEach(e -> e.getSkills().forEach(s -> skillNames.add(s.getSkillName())));
        List<MatrixRow> rows = all.stream().map(e -> {
            Map<String, MatrixCell> cells = new LinkedHashMap<>();
            e.getSkills().forEach(s -> cells.put(s.getSkillName(),
                    new MatrixCell(s.getId(), s.getCurrentLevel(), s.getRequiredLevel(), s.gap())));
            return new MatrixRow(e.getId(), e.getName(), e.getJobRole(), e.getDepartment(),
                    Readiness.of(e.getSkills()), cells);
        }).toList();
        return new SkillMatrix(new ArrayList<>(skillNames), rows);
    }

    // ---------------------------------------------------------------- commands

    @Transactional
    public EmployeeDetail create(EmployeeRequest req) {
        Employee e = new Employee(req.name().trim(), blankToNull(req.email()), department(req.department()),
                req.jobRole().trim());
        if (Boolean.TRUE.equals(req.applyRoleTemplate())) {
            roleTemplates.find(req.jobRole()).ifPresent(t ->
                    t.requiredSkills().forEach((skill, level) -> e.addSkill(skill, 0, level)));
        }
        return toDetail(employees.save(e));
    }

    @Transactional
    public EmployeeDetail update(Long id, EmployeeRequest req) {
        Employee e = load(id);
        e.setName(req.name().trim());
        e.setEmail(blankToNull(req.email()));
        e.setDepartment(department(req.department()));
        e.setJobRole(req.jobRole().trim());
        return toDetail(e);
    }

    @Transactional
    public void delete(Long id) {
        employees.delete(load(id));
    }

    @Transactional
    public SkillView addSkill(Long employeeId, SkillRequest req) {
        Employee e = load(employeeId);
        String name = req.skillName().trim();
        if (assessments.existsByEmployeeIdAndSkillNameIgnoreCase(employeeId, name)) {
            throw new ConflictException(e.getName() + " already has " + name + ". Edit the existing record instead.");
        }
        SkillAssessment s = e.addSkill(name, req.currentLevel(), req.requiredLevel());
        employees.saveAndFlush(e);
        return toView(s);
    }

    @Transactional
    public SkillView updateSkill(Long skillId, SkillRequest req) {
        SkillAssessment s = assessments.findById(skillId)
                .orElseThrow(() -> new NotFoundException("Skill record " + skillId + " not found"));
        String name = req.skillName().trim();
        if (!s.getSkillName().equalsIgnoreCase(name)
                && assessments.existsByEmployeeIdAndSkillNameIgnoreCase(s.getEmployee().getId(), name)) {
            throw new ConflictException("This employee already has a " + name + " record");
        }
        s.setSkillName(name);
        s.setCurrentLevel(req.currentLevel());
        s.setRequiredLevel(req.requiredLevel());
        assessments.flush();
        return toView(s);
    }

    @Transactional
    public void deleteSkill(Long skillId) {
        SkillAssessment s = assessments.findById(skillId)
                .orElseThrow(() -> new NotFoundException("Skill record " + skillId + " not found"));
        s.getEmployee().getSkills().remove(s);
    }

    @Transactional
    public void deleteAll() {
        employees.deleteAll();
    }

    // ----------------------------------------------------------------- mapping

    private Employee load(Long id) {
        if (id == null) {
            throw new BadRequestException("Employee id is required");
        }
        return employees.findWithSkillsById(id)
                .orElseThrow(() -> new NotFoundException("Employee " + id + " not found"));
    }

    EmployeeSummary toSummary(Employee e) {
        List<SkillAssessment> skills = e.getSkills();
        List<String> topGaps = skills.stream()
                .filter(s -> s.gap() > 0)
                .sorted(Comparator.comparingInt(SkillAssessment::gap).reversed())
                .limit(3)
                .map(SkillAssessment::getSkillName)
                .toList();
        return new EmployeeSummary(e.getId(), e.getName(), e.getEmail(), e.getDepartment(), e.getJobRole(),
                skills.size(), (int) skills.stream().filter(s -> s.gap() > 0).count(),
                (int) skills.stream().filter(SkillAssessment::isCritical).count(),
                Readiness.of(skills), topGaps);
    }

    private EmployeeDetail toDetail(Employee e) {
        EmployeeSummary s = toSummary(e);
        return new EmployeeDetail(s.id(), s.name(), s.email(), s.department(), s.jobRole(), s.skillCount(),
                s.gapCount(), s.criticalGaps(), s.readiness(), e.getCreatedAt(),
                e.getSkills().stream().map(this::toView).toList());
    }

    private SkillView toView(SkillAssessment s) {
        Employee e = s.getEmployee();
        return new SkillView(s.getId(), e.getId(), e.getName(), e.getJobRole(), e.getDepartment(),
                s.getSkillName(), s.getCurrentLevel(), s.getRequiredLevel(), s.gap(), s.isCritical(),
                s.getUpdatedAt());
    }

    private static String department(String d) {
        return d == null || d.isBlank() ? DEFAULT_DEPARTMENT : d.trim();
    }

    private static String blankToNull(String v) {
        return v == null || v.isBlank() ? null : v.trim();
    }

    private static double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }
}
