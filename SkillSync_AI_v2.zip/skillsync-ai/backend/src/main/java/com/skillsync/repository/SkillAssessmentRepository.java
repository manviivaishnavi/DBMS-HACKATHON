package com.skillsync.repository;

import com.skillsync.model.SkillAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SkillAssessmentRepository extends JpaRepository<SkillAssessment, Long> {

    boolean existsByEmployeeIdAndSkillNameIgnoreCase(Long employeeId, String skillName);
}
