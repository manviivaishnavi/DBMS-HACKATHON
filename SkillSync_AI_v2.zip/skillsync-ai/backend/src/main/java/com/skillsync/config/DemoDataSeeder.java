package com.skillsync.config;

import com.skillsync.model.Employee;
import com.skillsync.repository.EmployeeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Seeds a realistic 8-person team on first start so the dashboard, matrix,
 * mentor matching and risk detection all have something to show.
 */
@Component
public class DemoDataSeeder implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DemoDataSeeder.class);

    private final EmployeeRepository employees;
    private final boolean enabled;

    public DemoDataSeeder(EmployeeRepository employees, @Value("${app.demo.seed:true}") boolean enabled) {
        this.employees = employees;
        this.enabled = enabled;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (enabled && employees.count() == 0) {
            seed();
            log.info("Seeded {} demo employees", employees.count());
        }
    }

    @Transactional
    public void seed() {
        // name, email, department, role, then (skill, current, required) triples
        List<Object[]> team = List.of(
                person("Aarav Sharma", "Engineering", "Java Developer",
                        "Java", 4, 5, "Spring Boot", 1, 4, "SQL", 2, 4, "Cloud & DevOps", 1, 2, "Communication", 3, 3),
                person("Priya Nair", "Engineering", "Frontend Developer",
                        "JavaScript", 5, 5, "React", 4, 5, "Communication", 4, 3, "Cloud & DevOps", 1, 2),
                person("Vikram Singh", "Engineering", "Software Engineer",
                        "Java", 5, 4, "Spring Boot", 5, 3, "JavaScript", 3, 4, "React", 2, 4, "SQL", 4, 4, "Communication", 3, 3),
                person("Arjun Rao", "Engineering", "Engineering Manager",
                        "Leadership", 3, 5, "Communication", 4, 5, "Java", 4, 3, "Cloud & DevOps", 2, 2),
                person("Rohan Mehta", "Data", "Data Analyst",
                        "SQL", 3, 5, "Python", 2, 4, "Data Analysis", 3, 5, "Communication", 3, 4),
                person("Kavya Reddy", "Data", "Data Analyst",
                        "SQL", 2, 5, "Python", 1, 4, "Data Analysis", 2, 5, "Communication", 5, 4),
                person("Ananya Iyer", "Data", "Python Developer",
                        "Python", 5, 5, "SQL", 5, 4, "Cloud & DevOps", 2, 3, "Communication", 2, 3),
                person("Sneha Kapoor", "Platform", "DevOps Engineer",
                        "Cloud & DevOps", 3, 5, "Python", 3, 3, "Java", 2, 2, "Communication", 4, 3)
        );
        for (Object[] p : team) {
            String name = (String) p[0];
            String email = name.toLowerCase().replace(' ', '.') + "@example.com";
            Employee e = new Employee(name, email, (String) p[1], (String) p[2]);
            for (int i = 3; i < p.length; i += 3) {
                e.addSkill((String) p[i], (Integer) p[i + 1], (Integer) p[i + 2]);
            }
            employees.save(e);
        }
    }

    private static Object[] person(Object... values) {
        return values;
    }
}
