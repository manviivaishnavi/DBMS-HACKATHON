package com.skillsync.service;

import com.skillsync.exception.ApiExceptions.AiUnavailableException;
import com.skillsync.exception.ApiExceptions.BadRequestException;
import com.skillsync.model.Employee;
import com.skillsync.model.SkillAssessment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Talks to the Python recommendation service. Payloads are always built from
 * the database, never from whatever the browser sends, so the AI sees trusted data.
 */
@Component
public class AiClient {

    private static final ParameterizedTypeReference<Map<String, Object>> JSON_MAP = new ParameterizedTypeReference<>() {
    };

    private final RestClient rest;
    private final String baseUrl;

    public AiClient(RestClient.Builder builder,
                    @Value("${python.ai.base-url}") String baseUrl,
                    @Value("${python.ai.timeout-ms:25000}") int timeoutMs) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(Math.min(timeoutMs, 3000));
        factory.setReadTimeout(timeoutMs);
        this.baseUrl = baseUrl;
        this.rest = builder.baseUrl(baseUrl).requestFactory(factory).build();
    }

    public Map<String, Object> recommend(Employee employee, double hoursPerWeek) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("employee", Map.of(
                "id", employee.getId(),
                "name", employee.getName(),
                "jobRole", employee.getJobRole(),
                "department", employee.getDepartment()));
        body.put("skills", skills(employee.getSkills()));
        body.put("hoursPerWeek", hoursPerWeek);
        return post("/recommend", body);
    }

    public Map<String, Object> teamInsights(List<Employee> employees) {
        List<Map<String, Object>> people = employees.stream().map(e -> {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("id", e.getId());
            p.put("name", e.getName());
            p.put("jobRole", e.getJobRole());
            p.put("department", e.getDepartment());
            p.put("skills", skills(e.getSkills()));
            return p;
        }).toList();
        return post("/team-insights", Map.of("employees", people));
    }

    public Map<String, Object> health() {
        try {
            Map<String, Object> res = rest.get().uri("/health").retrieve().body(JSON_MAP);
            return res != null ? res : Map.of("status", "unknown");
        } catch (RestClientException ex) {
            return Map.of("status", "down", "url", baseUrl);
        }
    }

    private static List<Map<String, Object>> skills(List<SkillAssessment> skills) {
        return skills.stream().map(s -> Map.<String, Object>of(
                "skillName", s.getSkillName(),
                "currentLevel", s.getCurrentLevel(),
                "requiredLevel", s.getRequiredLevel())).toList();
    }

    private Map<String, Object> post(String path, Object body) {
        try {
            Map<String, Object> res = rest.post().uri(path)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(body)
                    .retrieve()
                    .body(JSON_MAP);
            if (res == null) {
                throw new AiUnavailableException("AI service returned an empty response", null);
            }
            return res;
        } catch (HttpClientErrorException ex) {
            throw new BadRequestException("AI service rejected the request: " + ex.getResponseBodyAsString());
        } catch (RestClientException ex) {
            throw new AiUnavailableException(
                    "AI service is unavailable at " + baseUrl + ". Start it with: cd python-ai && python app.py", ex);
        }
    }
}
