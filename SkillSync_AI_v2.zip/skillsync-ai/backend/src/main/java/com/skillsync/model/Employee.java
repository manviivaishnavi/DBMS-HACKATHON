package com.skillsync.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(length = 120)
    private String email;

    @Column(nullable = false, length = 60)
    private String department;

    @Column(nullable = false, length = 60)
    private String jobRole;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("skillName ASC")
    private List<SkillAssessment> skills = new ArrayList<>();

    protected Employee() {
    }

    public Employee(String name, String email, String department, String jobRole) {
        this.name = name;
        this.email = email;
        this.department = department;
        this.jobRole = jobRole;
    }

    @PrePersist
    void onCreate() {
        if (createdAt == null) {
            createdAt = Instant.now();
        }
    }

    public SkillAssessment addSkill(String skillName, int currentLevel, int requiredLevel) {
        SkillAssessment assessment = new SkillAssessment(this, skillName, currentLevel, requiredLevel);
        skills.add(assessment);
        return assessment;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getDepartment() { return department; }
    public String getJobRole() { return jobRole; }
    public Instant getCreatedAt() { return createdAt; }
    public List<SkillAssessment> getSkills() { return skills; }

    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setDepartment(String department) { this.department = department; }
    public void setJobRole(String jobRole) { this.jobRole = jobRole; }
}
