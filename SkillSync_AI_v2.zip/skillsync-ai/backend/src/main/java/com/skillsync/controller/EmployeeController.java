package com.skillsync.controller;

import com.skillsync.dto.Dtos.EmployeeDetail;
import com.skillsync.dto.Dtos.EmployeeRequest;
import com.skillsync.dto.Dtos.EmployeeSummary;
import com.skillsync.dto.Dtos.SkillRequest;
import com.skillsync.dto.Dtos.SkillView;
import com.skillsync.service.AiClient;
import com.skillsync.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService service;
    private final AiClient ai;

    public EmployeeController(EmployeeService service, AiClient ai) {
        this.service = service;
        this.ai = ai;
    }

    @GetMapping
    public List<EmployeeSummary> list(@RequestParam(required = false) String search,
                                      @RequestParam(required = false) String department) {
        return service.list(search, department);
    }

    @GetMapping("/{id}")
    public EmployeeDetail get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EmployeeDetail create(@Valid @RequestBody EmployeeRequest request) {
        return service.create(request);
    }

    @PutMapping("/{id}")
    public EmployeeDetail update(@PathVariable Long id, @Valid @RequestBody EmployeeRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @PostMapping("/{id}/skills")
    @ResponseStatus(HttpStatus.CREATED)
    public SkillView addSkill(@PathVariable Long id, @Valid @RequestBody SkillRequest request) {
        return service.addSkill(id, request);
    }

    /** Personal AI learning plan built from this employee's stored assessments. */
    @PostMapping("/{id}/recommendations")
    public Map<String, Object> recommendations(@PathVariable Long id,
                                               @RequestParam(defaultValue = "6") double hoursPerWeek) {
        double hours = Math.max(1, Math.min(40, hoursPerWeek));
        return ai.recommend(service.loadWithSkills(id), hours);
    }
}
