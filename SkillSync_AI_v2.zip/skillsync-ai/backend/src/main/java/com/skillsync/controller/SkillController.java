package com.skillsync.controller;

import com.skillsync.dto.Dtos.SkillRequest;
import com.skillsync.dto.Dtos.SkillView;
import com.skillsync.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/skills")
public class SkillController {

    private final EmployeeService service;

    public SkillController(EmployeeService service) {
        this.service = service;
    }

    @GetMapping
    public List<SkillView> all() {
        return service.allSkills();
    }

    @PutMapping("/{id}")
    public SkillView update(@PathVariable Long id, @Valid @RequestBody SkillRequest request) {
        return service.updateSkill(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.deleteSkill(id);
    }
}
