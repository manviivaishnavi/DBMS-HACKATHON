package com.skillsync.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/** Request and response payloads. Entities are never exposed directly over the API. */
public final class Dtos {

    private Dtos() {
    }

    // ---------- Requests ----------

    public record EmployeeRequest(
            @NotBlank(message = "Name is required") @Size(max = 100) String name,
            @Email(message = "Email must be valid") @Size(max = 120) String email,
            @Size(max = 60) String department,
            @NotBlank(message = "Job role is required") @Size(max = 60) String jobRole,
            Boolean applyRoleTemplate) {
    }

    public record SkillRequest(
            @NotBlank(message = "Skill name is required") @Size(max = 60) String skillName,
            @NotNull @Min(value = 0, message = "Current level must be 0-5") @Max(value = 5, message = "Current level must be 0-5") Integer currentLevel,
            @NotNull @Min(value = 1, message = "Required level must be 1-5") @Max(value = 5, message = "Required level must be 1-5") Integer requiredLevel) {
    }

    // ---------- Responses ----------

    public record SkillView(Long id, Long employeeId, String employeeName, String jobRole, String department,
                            String skillName, int currentLevel, int requiredLevel, int gap, boolean critical,
                            Instant updatedAt) {
    }

    public record EmployeeSummary(Long id, String name, String email, String department, String jobRole,
                                  int skillCount, int gapCount, int criticalGaps, int readiness,
                                  List<String> topGaps) {
    }

    public record EmployeeDetail(Long id, String name, String email, String department, String jobRole,
                                 int skillCount, int gapCount, int criticalGaps, int readiness,
                                 Instant createdAt, List<SkillView> skills) {
    }

    public record SkillGapStat(String skillName, int tracked, double avgCurrent, double avgRequired,
                               double avgGap, int peopleWithGap) {
    }

    public record DepartmentStat(String department, int employees, int readiness, int gaps) {
    }

    public record DashboardStats(long employees, long skillsTracked, long skillGaps, long criticalGaps,
                                 int readiness, List<SkillGapStat> skillBreakdown,
                                 List<DepartmentStat> departments, List<EmployeeSummary> needsAttention) {
    }

    public record MatrixCell(Long assessmentId, int current, int required, int gap) {
    }

    public record MatrixRow(Long employeeId, String name, String jobRole, String department, int readiness,
                            Map<String, MatrixCell> cells) {
    }

    public record SkillMatrix(List<String> skills, List<MatrixRow> rows) {
    }

    public record RoleTemplate(String role, String description, Map<String, Integer> requiredSkills) {
    }

    public record ImportResult(int employeesCreated, int skillsCreated, int skillsUpdated, int rowsSkipped,
                               List<String> errors) {
    }
}
