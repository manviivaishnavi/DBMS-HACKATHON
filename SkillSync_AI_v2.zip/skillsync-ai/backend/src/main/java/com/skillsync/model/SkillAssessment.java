package com.skillsync.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

import java.time.Instant;

/** One employee's proficiency in one skill, against the level their role requires. */
@Entity
@Table(name = "skill_assessments",
       uniqueConstraints = @UniqueConstraint(name = "uk_employee_skill", columnNames = {"employee_id", "skill_name"}))
public class SkillAssessment {

    public static final int MIN_LEVEL = 0;
    public static final int MAX_LEVEL = 5;
    /** A gap of this many levels or more is flagged as critical. */
    public static final int CRITICAL_GAP = 3;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(name = "skill_name", nullable = false, length = 60)
    private String skillName;

    @Column(nullable = false)
    private int currentLevel;

    @Column(nullable = false)
    private int requiredLevel;

    @Column(nullable = false)
    private Instant updatedAt;

    protected SkillAssessment() {
    }

    public SkillAssessment(Employee employee, String skillName, int currentLevel, int requiredLevel) {
        this.employee = employee;
        this.skillName = skillName;
        this.currentLevel = currentLevel;
        this.requiredLevel = requiredLevel;
    }

    @PrePersist
    @PreUpdate
    void touch() {
        updatedAt = Instant.now();
    }

    public int gap() {
        return Math.max(0, requiredLevel - currentLevel);
    }

    public boolean isCritical() {
        return gap() >= CRITICAL_GAP;
    }

    public Long getId() { return id; }
    public Employee getEmployee() { return employee; }
    public String getSkillName() { return skillName; }
    public int getCurrentLevel() { return currentLevel; }
    public int getRequiredLevel() { return requiredLevel; }
    public Instant getUpdatedAt() { return updatedAt; }

    public void setSkillName(String skillName) { this.skillName = skillName; }
    public void setCurrentLevel(int currentLevel) { this.currentLevel = currentLevel; }
    public void setRequiredLevel(int requiredLevel) { this.requiredLevel = requiredLevel; }
}
