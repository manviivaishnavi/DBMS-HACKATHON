package com.skillsync.service;

import com.skillsync.model.SkillAssessment;

import java.util.Collection;

/**
 * Single source of truth for the readiness formula (mirrors the Python engine):
 * <pre>readiness = sum(min(current, required)) / sum(required) * 100</pre>
 * Exceeding a target never hides a gap elsewhere.
 */
public final class Readiness {

    private Readiness() {
    }

    public static int of(Collection<SkillAssessment> skills) {
        int required = 0;
        int achieved = 0;
        for (SkillAssessment s : skills) {
            required += s.getRequiredLevel();
            achieved += Math.min(s.getCurrentLevel(), s.getRequiredLevel());
        }
        return required == 0 ? 0 : (int) Math.round(achieved * 100.0 / required);
    }
}
