#!/usr/bin/env bash
# Starts the whole stack locally without Docker or MySQL (H2 demo database).
# Ctrl+C stops everything.
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
trap 'kill 0' EXIT

echo "▶ Python AI engine  → http://localhost:5001"
( cd "$ROOT/python-ai" && { [ -d .venv ] || python3 -m venv .venv; } && . .venv/bin/activate \
  && pip install -q -r requirements.txt && python app.py ) &

echo "▶ Spring Boot API   → http://localhost:8080"
( cd "$ROOT/backend" && mvn -q spring-boot:run ) &

echo "▶ React frontend    → http://localhost:5173"
( cd "$ROOT/frontend" && { [ -d node_modules ] || npm install; } && npm run dev ) &

wait
