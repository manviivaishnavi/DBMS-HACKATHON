import { useCallback, useEffect, useMemo, useState } from 'react'
import { api } from './api.js'
import { EmployeeForm } from './components/forms.jsx'
import { Icon, useToast } from './components/ui.jsx'
import EmployeeDetail from './views/EmployeeDetail.jsx'
import Employees from './views/Employees.jsx'
import Insights from './views/Insights.jsx'
import Matrix from './views/Matrix.jsx'
import Overview from './views/Overview.jsx'

const NAV = [
  { path: '/', label: 'Overview', icon: 'overview', title: 'Skill intelligence dashboard', sub: 'Understand capabilities. Identify gaps. Build stronger teams.' },
  { path: '/employees', label: 'Employees', icon: 'people', title: 'Employees', sub: 'Profiles, assessments and personal AI learning plans' },
  { path: '/matrix', label: 'Skill matrix', icon: 'grid', title: 'Skill matrix', sub: 'Every person × every skill. Import and export CSV.' },
  { path: '/insights', label: 'AI insights', icon: 'spark', title: 'AI team insights', sub: 'Cohort training, mentor matching and expertise risk' },
]

const PALETTE = {
  light: { accent: '#5b4fd6', accentSoft: '#d9d5fb', accentSoftStroke: '#a79ff0', line: '#e9e8f2', muted: '#8a89a3', hover: 'rgba(91,79,214,0.06)' },
  dark: { accent: '#9d93ff', accentSoft: '#3b3670', accentSoftStroke: '#6c64c4', line: '#2c2b42', muted: '#8f8eaa', hover: 'rgba(157,147,255,0.08)' },
}

function useHashRoute() {
  const read = () => window.location.hash.replace(/^#/, '') || '/'
  const [path, setPath] = useState(read)
  useEffect(() => {
    const on = () => { setPath(read()); window.scrollTo({ top: 0 }) }
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  const navigate = useCallback(p => { window.location.hash = p }, [])
  return [path, navigate]
}

function useTheme() {
  const initial = () => {
    try { return localStorage.getItem('skillsync-theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') }
    catch { return 'light' }
  }
  const [theme, setTheme] = useState(initial)
  useEffect(() => {
    document.documentElement.dataset.theme = theme
    try { localStorage.setItem('skillsync-theme', theme) } catch { /* private mode */ }
  }, [theme])
  return [theme, () => setTheme(t => (t === 'dark' ? 'light' : 'dark'))]
}

export default function App() {
  const toast = useToast()
  const [path, navigate] = useHashRoute()
  const [theme, toggleTheme] = useTheme()
  const [dashboard, setDashboard] = useState(null)
  const [loading, setLoading] = useState(true)
  const [roles, setRoles] = useState(null)
  const [health, setHealth] = useState(null)
  const [refreshKey, setRefreshKey] = useState(0)
  const [adding, setAdding] = useState(false)
  const [insightsCache, setInsightsCache] = useState(null)
  const [employeeIndex, setEmployeeIndex] = useState({})
  const [backendDown, setBackendDown] = useState(false)

  const refresh = useCallback(() => setRefreshKey(k => k + 1), [])

  useEffect(() => {
    setLoading(true)
    Promise.all([api.dashboard(), api.employees()])
      .then(([d, list]) => {
        setDashboard(d)
        setEmployeeIndex(Object.fromEntries(list.map(e => [e.name, e.id])))
        setBackendDown(false)
      })
      .catch(err => { setBackendDown(true); if (err.status !== 0) toast(err.message, 'error') })
      .finally(() => setLoading(false))
  }, [refreshKey, toast])

  useEffect(() => { api.roles().then(setRoles).catch(() => setRoles({ roles: [], skills: [] })) }, [])

  useEffect(() => {
    const check = () => api.health().then(setHealth).catch(() => setHealth(null))
    check()
    const t = setInterval(check, 15000)
    return () => clearInterval(t)
  }, [])

  const employeeMatch = path.match(/^\/employees\/(\d+)$/)
  const section = employeeMatch ? NAV[1] : NAV.find(n => n.path === path) || NAV[0]
  const colors = PALETTE[theme]
  const aiUp = health?.ai?.status === 'ok'

  const view = useMemo(() => {
    if (employeeMatch) {
      return <EmployeeDetail id={Number(employeeMatch[1])} roles={roles} navigate={navigate} onChanged={refresh} colors={colors} />
    }
    switch (section.path) {
      case '/employees': return <Employees navigate={navigate} refreshKey={refreshKey} onAddEmployee={() => setAdding(true)} />
      case '/matrix': return <Matrix navigate={navigate} refreshKey={refreshKey} onChanged={refresh} />
      case '/insights': return <Insights cache={insightsCache} setCache={setInsightsCache} refreshKey={refreshKey} navigate={navigate} employeesByName={employeeIndex} />
      default: return <Overview dashboard={dashboard} loading={loading} navigate={navigate} onAddEmployee={() => setAdding(true)} colors={colors} />
    }
  }, [employeeMatch?.[1], section.path, roles, navigate, refresh, colors, refreshKey, insightsCache, employeeIndex, dashboard, loading]) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="shell">
      <a href="#main" className="skip">Skip to content</a>
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark"><Icon name="spark" size={20} /></span>
          <div>SkillSync<small>AI WORKFORCE INTELLIGENCE</small></div>
        </div>
        <nav aria-label="Main">
          {NAV.map(n => (
            <a key={n.path} href={`#${n.path}`} className={`nav ${section.path === n.path ? 'active' : ''}`} aria-current={section.path === n.path ? 'page' : undefined}>
              <Icon name={n.icon} /> {n.label}
            </a>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div className="services">
            <span><i className={health ? 'up' : 'down'} /> API</span>
            <span><i className={aiUp ? 'up' : 'down'} /> AI engine</span>
            {health?.ai?.llmEnabled && <span><i className="up" /> LLM</span>}
          </div>
          <button className="theme-btn" onClick={toggleTheme} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}>
            <Icon name={theme === 'dark' ? 'sun' : 'moon'} size={16} /> {theme === 'dark' ? 'Light' : 'Dark'} mode
          </button>
        </div>
      </aside>

      <main className="main" id="main">
        <header className="topbar">
          <div>
            <span className="eyebrow">WORKFORCE DEVELOPMENT / {section.label.toUpperCase()}</span>
            <h1>{section.title}</h1>
            <p>{section.sub}</p>
          </div>
          <div className="top-actions">
            <button className="icon-btn mobile-only" onClick={toggleTheme} aria-label="Toggle theme"><Icon name={theme === 'dark' ? 'sun' : 'moon'} /></button>
            <button className="btn primary" onClick={() => setAdding(true)}><Icon name="plus" /> <span className="hide-sm">Add employee</span></button>
          </div>
        </header>

        {backendDown && (
          <div className="alert">
            <b>Backend not reachable.</b> Start the Spring Boot API (<code>cd backend &amp;&amp; mvn spring-boot:run</code>) then <button className="link" onClick={refresh}>retry</button>.
          </div>
        )}
        {health && !aiUp && !backendDown && (
          <div className="alert soft">AI engine is offline, so learning plans and team insights are unavailable. Start it with <code>cd python-ai &amp;&amp; python app.py</code>.</div>
        )}

        {view}

        <footer>SkillSync AI · Recommendations are decision-support estimates, not a basis for employment decisions.</footer>
      </main>

      <nav className="bottom-nav" aria-label="Main">
        {NAV.map(n => (
          <a key={n.path} href={`#${n.path}`} className={section.path === n.path ? 'active' : ''}>
            <Icon name={n.icon} /><span>{n.label}</span>
          </a>
        ))}
      </nav>

      {adding && (
        <EmployeeForm roles={roles} onClose={() => setAdding(false)}
          onSaved={saved => { setAdding(false); refresh(); navigate(`/employees/${saved.id}`) }} />
      )}
    </div>
  )
}
