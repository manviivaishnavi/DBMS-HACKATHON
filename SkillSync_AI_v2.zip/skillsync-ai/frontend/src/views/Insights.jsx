import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { Avatar, Bar, Empty, Icon, ReadinessRing, Skeleton, SourceTag } from '../components/ui.jsx'

export default function Insights({ cache, setCache, refreshKey, navigate, employeesByName }) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const data = cache?.key === refreshKey ? cache.data : null

  async function run() {
    setBusy(true); setError('')
    try { setCache({ key: refreshKey, data: await api.teamInsights() }) }
    catch (err) { setError(err.message) }
    finally { setBusy(false) }
  }

  useEffect(() => { if (!data && !busy && !error) run() }, [refreshKey]) // eslint-disable-line react-hooks/exhaustive-deps

  const open = name => { const id = employeesByName[name]; if (id) navigate(`/employees/${id}`) }

  if (error) {
    return (
      <div className="panel">
        <div className="alert">{error}</div>
        <Empty title="AI engine unreachable" icon="warning">
          Start the Python service (<code>cd python-ai &amp;&amp; python app.py</code>) and try again.
          <br /><button className="btn primary mt" onClick={run}><Icon name="refresh" /> Retry</button>
        </Empty>
      </div>
    )
  }
  if (!data) return <div className="panel"><Skeleton h={90} /><br /><Skeleton h={260} /></div>

  return (
    <>
      <section className="panel ai-hero">
        <ReadinessRing value={data.teamReadiness} size={120} label="TEAM" />
        <div className="grow">
          <h2><Icon name="spark" /> Team capability briefing</h2>
          <p className="lead">{data.summary?.text}</p>
          <div className="row-between">
            <SourceTag source={data.summary?.source} />
            <button className="btn ghost sm" onClick={run} disabled={busy}><Icon name="refresh" size={15} /> {busy ? 'Refreshing…' : 'Refresh'}</button>
          </div>
        </div>
      </section>

      <section className="stats">
        <MiniStat label="Group training cohorts" value={data.cohorts.length} icon="people" />
        <MiniStat label="Internal mentor pairs" value={data.mentorPairs.length} icon="mentor" />
        <MiniStat label="Expertise risks" value={data.risks.length} icon="warning" tone={data.risks.some(r => r.severity === 'High') ? 'bad' : 'warn'} />
        <MiniStat label="People below 60%" value={data.employeesNeedingSupport.length} icon="spark" />
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-head"><div><h2>Group training cohorts</h2><p>Same gap, several people: one session instead of many</p></div></div>
          {data.cohorts.length ? (
            <div className="stack">
              {data.cohorts.map(c => (
                <article className="cohort" key={c.skillName}>
                  <div className="cohort-top"><b>{c.skillName}</b><span className="pill">{c.size} learners</span></div>
                  <p><Icon name="book" size={14} /> {c.suggestedCourse} <small>· {c.format} · {c.durationHours} h</small></p>
                  <div className="avatars">
                    {c.learners.map(n => <button key={n} onClick={() => open(n)} title={n} className="avatar-btn"><Avatar name={n} size={28} /></button>)}
                    <small>avg gap {c.avgGap} levels</small>
                  </div>
                </article>
              ))}
            </div>
          ) : <Empty title="No shared gaps" icon="check" />}
        </div>

        <div className="panel">
          <div className="panel-head"><div><h2>Mentor matches</h2><p>Experts (level 4+) paired with colleagues 2+ levels short</p></div></div>
          {data.mentorPairs.length ? (
            <ul className="pairs">
              {data.mentorPairs.map((p, i) => (
                <li key={i}>
                  <button className="person" onClick={() => open(p.mentor)}><Avatar name={p.mentor} size={30} /><span><b>{p.mentor}</b><small>Level {p.mentorLevel}</small></span></button>
                  <div className="pair-skill"><span>{p.skillName}</span><i>→</i>{p.sameDepartment && <small>same dept</small>}</div>
                  <button className="person" onClick={() => open(p.mentee)}><Avatar name={p.mentee} size={30} /><span><b>{p.mentee}</b><small>{p.menteeLevel} → {p.menteeTarget}</small></span></button>
                </li>
              ))}
            </ul>
          ) : <Empty title="No mentor matches" icon="mentor">Nobody at level 4+ in a skill where a colleague is 2+ levels short.</Empty>}
        </div>
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-head"><div><h2>Expertise risks</h2><p>Skills with no expert, or only one</p></div></div>
          {data.risks.length ? (
            <div className="stack">
              {data.risks.map(r => (
                <article key={r.skillName + r.type} className={`risk ${r.severity.toLowerCase()}`}>
                  <Icon name="warning" size={18} />
                  <div><b>{r.type}: {r.skillName}</b><p>{r.detail}</p></div>
                </article>
              ))}
            </div>
          ) : <Empty title="No concentration risks" icon="check" />}
        </div>

        <div className="panel">
          <div className="panel-head"><div><h2>Skill coverage</h2><p>Average gap and in-house experts per skill</p></div></div>
          <div className="table-wrap"><table className="coverage">
            <thead><tr><th>Skill</th><th>Avg gap</th><th>Below target</th><th>Experts</th></tr></thead>
            <tbody>
              {data.skills.map(s => (
                <tr key={s.skillName}>
                  <td><b>{s.skillName}</b><small>{s.category}</small></td>
                  <td><div className="gapbar"><Bar value={s.avgGap} max={3} tone={s.avgGap >= 2 ? 'var(--bad)' : s.avgGap >= 1 ? 'var(--warn)' : 'var(--good)'} /><span>{s.avgGap}</span></div></td>
                  <td>{s.peopleWithGap.length}/{s.tracked}</td>
                  <td>{s.experts.length || <span className="bad-text">0</span>}</td>
                </tr>
              ))}
            </tbody>
          </table></div>
        </div>
      </section>
    </>
  )
}

function MiniStat({ label, value, icon, tone }) {
  return (
    <div className="stat">
      <div className="stat-top"><span>{label}</span><i className={tone}><Icon name={icon} size={16} /></i></div>
      <strong>{value}</strong>
    </div>
  )
}
