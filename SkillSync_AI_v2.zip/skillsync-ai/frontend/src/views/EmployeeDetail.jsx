import { useCallback, useEffect, useState } from 'react'
import { PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer, Legend, Tooltip } from 'recharts'
import { api, LEVELS } from '../api.js'
import { EmployeeForm, SkillForm } from '../components/forms.jsx'
import { Avatar, Confirm, Empty, GapBadge, Icon, LevelDots, Priority, ReadinessRing, Skeleton, SourceTag, useToast } from '../components/ui.jsx'

export default function EmployeeDetail({ id, roles, navigate, onChanged, colors }) {
  const toast = useToast()
  const [emp, setEmp] = useState(null)
  const [missing, setMissing] = useState(false)
  const [modal, setModal] = useState(null)
  const [plan, setPlan] = useState(null)
  const [planBusy, setPlanBusy] = useState(false)
  const [hours, setHours] = useState(6)
  const [planError, setPlanError] = useState('')

  const load = useCallback(() => {
    api.employee(id).then(setEmp).catch(err => {
      if (err.status === 404) setMissing(true)
      else toast(err.message, 'error')
    })
  }, [id, toast])

  useEffect(() => { setPlan(null); setEmp(null); setMissing(false); load() }, [load])

  const changed = () => { load(); setPlan(null); onChanged() }

  async function generate(h = hours) {
    setPlanBusy(true); setPlanError('')
    try { setPlan(await api.recommendations(id, h)) }
    catch (err) { setPlanError(err.message) }
    finally { setPlanBusy(false) }
  }

  if (missing) return <div className="panel"><Empty title="Employee not found" icon="people"><button className="btn ghost mt" onClick={() => navigate('/employees')}>Back to employees</button></Empty></div>
  if (!emp) return <div className="panel"><Skeleton h={160} /><br /><Skeleton h={300} /></div>

  const radar = emp.skills.map(s => ({ skill: s.skillName, Current: s.currentLevel, Required: s.requiredLevel }))

  return (
    <>
      <button className="back" onClick={() => navigate('/employees')}><Icon name="back" size={16} /> All employees</button>

      <section className="panel profile">
        <Avatar name={emp.name} size={64} />
        <div className="grow">
          <h2>{emp.name}</h2>
          <p>{emp.jobRole} · {emp.department}{emp.email && <> · <a href={`mailto:${emp.email}`}>{emp.email}</a></>}</p>
          <div className="chips">
            <span>{emp.skillCount} skills</span>
            <span className={emp.gapCount ? 'warn-text' : 'good-text'}>{emp.gapCount} gaps</span>
            {emp.criticalGaps > 0 && <span className="bad-text">{emp.criticalGaps} critical</span>}
          </div>
        </div>
        <ReadinessRing value={emp.readiness} size={112} />
        <div className="profile-actions">
          <button className="btn ghost sm" onClick={() => setModal({ type: 'edit' })}><Icon name="edit" size={15} /> Edit</button>
          <button className="btn ghost sm danger-text" onClick={() => setModal({ type: 'delete' })}><Icon name="trash" size={15} /> Delete</button>
        </div>
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-head">
            <div><h2>Skill assessments</h2><p>Click a row to update levels</p></div>
            <button className="btn primary sm" onClick={() => setModal({ type: 'skill' })}><Icon name="plus" size={15} /> Add skill</button>
          </div>
          {emp.skills.length ? (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Skill</th><th>Level</th><th>Current</th><th>Target</th><th>Gap</th><th aria-label="Actions" /></tr></thead>
                <tbody>
                  {emp.skills.map(s => (
                    <tr key={s.id} className="clickable" onClick={() => setModal({ type: 'skill', skill: s })}>
                      <td><b>{s.skillName}</b></td>
                      <td><LevelDots current={s.currentLevel} required={s.requiredLevel} /></td>
                      <td>{s.currentLevel} <small>{LEVELS[s.currentLevel]}</small></td>
                      <td>{s.requiredLevel} <small>{LEVELS[s.requiredLevel]}</small></td>
                      <td><GapBadge gap={s.gap} /></td>
                      <td>
                        <button className="icon-btn" aria-label={`Delete ${s.skillName}`} onClick={e => { e.stopPropagation(); setModal({ type: 'delete-skill', skill: s }) }}>
                          <Icon name="trash" size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <Empty title="No skills yet" icon="book">Add a skill to start tracking gaps.</Empty>}
        </div>

        <div className="panel">
          <div className="panel-head"><div><h2>Skill profile</h2><p>Current vs. required, at a glance</p></div></div>
          {radar.length >= 3 ? (
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={radar} outerRadius="72%">
                <PolarGrid stroke={colors.line} />
                <PolarAngleAxis dataKey="skill" tick={{ fontSize: 11, fill: colors.muted }} />
                <PolarRadiusAxis domain={[0, 5]} tickCount={6} tick={false} axisLine={false} />
                <Radar name="Required" dataKey="Required" stroke={colors.accentSoftStroke} fill={colors.accentSoft} fillOpacity={0.5} />
                <Radar name="Current" dataKey="Current" stroke={colors.accent} fill={colors.accent} fillOpacity={0.35} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Tooltip />
              </RadarChart>
            </ResponsiveContainer>
          ) : <Empty title="Add 3+ skills" icon="spark">The radar chart appears once there are at least three skills.</Empty>}
        </div>
      </section>

      <section className="panel ai-panel">
        <div className="panel-head">
          <div><h2><Icon name="spark" /> AI learning plan</h2><p>Prerequisite-aware path, ranked priorities and a week-by-week schedule</p></div>
          <div className="plan-controls">
            <label className="hours">
              <span>{hours} h/week</span>
              <input type="range" min="2" max="20" value={hours} onChange={e => setHours(Number(e.target.value))} onMouseUp={() => plan && generate()} onTouchEnd={() => plan && generate()} onKeyUp={e => e.key.startsWith('Arrow') && plan && generate()} aria-label="Learning hours per week" />
            </label>
            <button className="btn primary" onClick={() => generate()} disabled={planBusy || !emp.skills.length}>
              <Icon name={plan ? 'refresh' : 'spark'} /> {planBusy ? 'Analysing…' : plan ? 'Regenerate' : 'Generate plan'}
            </button>
          </div>
        </div>
        {planError && <div className="alert">{planError}</div>}
        {planBusy && !plan && <div className="plan-loading"><Skeleton h={60} /><Skeleton h={140} /></div>}
        {plan && <Plan plan={plan} />}
        {!plan && !planBusy && !planError && (
          <Empty title="Ready when you are" icon="spark">The engine scores every gap by size, business importance and how many other skills it unlocks, then builds a schedule around {emp.name.split(' ')[0]}'s available time.</Empty>
        )}
      </section>

      {modal?.type === 'edit' && <EmployeeForm employee={emp} roles={roles} onClose={() => setModal(null)} onSaved={() => { setModal(null); changed() }} />}
      {modal?.type === 'skill' && (
        <SkillForm employeeId={emp.id} skill={modal.skill} knownSkills={roles?.skills || []} existing={emp.skills.map(s => s.skillName)}
          onClose={() => setModal(null)} onSaved={() => { setModal(null); changed() }} />
      )}
      {modal?.type === 'delete' && (
        <Confirm title={`Delete ${emp.name}?`} message="This removes the employee and all of their skill assessments. This cannot be undone."
          onClose={() => setModal(null)}
          onConfirm={async () => {
            try { await api.deleteEmployee(emp.id); toast(`${emp.name} deleted`); onChanged(); navigate('/employees') }
            catch (err) { toast(err.message, 'error'); setModal(null) }
          }} />
      )}
      {modal?.type === 'delete-skill' && (
        <Confirm title={`Remove ${modal.skill.skillName}?`} message={`Delete this assessment from ${emp.name}'s profile.`} confirmLabel="Remove"
          onClose={() => setModal(null)}
          onConfirm={async () => {
            try { await api.deleteSkill(modal.skill.id); toast(`${modal.skill.skillName} removed`); setModal(null); changed() }
            catch (err) { toast(err.message, 'error'); setModal(null) }
          }} />
      )}
    </>
  )
}

function Plan({ plan }) {
  const [showAllWeeks, setShowAllWeeks] = useState(false)
  const weeks = showAllWeeks ? plan.weeklyPlan : plan.weeklyPlan.slice(0, 6)
  return (
    <div className="plan">
      <div className="summary-box">
        <p>{plan.summary?.text}</p>
        <SourceTag source={plan.summary?.source} />
      </div>

      <div className="plan-metrics">
        <div><small>Readiness now</small><b>{plan.readinessScore}%</b></div>
        <div><small>Gaps to close</small><b>{plan.totalGaps}</b></div>
        <div><small>Effort</small><b>{plan.totalEstimatedHours} h</b></div>
        <div><small>Time to target</small><b>{plan.estimatedWeeks} wk</b></div>
      </div>

      {plan.recommendations.length === 0 ? (
        <Empty title="No gaps — on target everywhere" icon="check">
          {plan.strengths.length ? `Strengths: ${plan.strengths.join(', ')}. A great candidate to mentor others.` : null}
        </Empty>
      ) : (
        <>
          <h3>Learning path</h3>
          <ol className="path">
            {plan.learningPath.map((s, i) => <li key={s}><span>{i + 1}</span>{s}</li>)}
          </ol>

          <h3>Prioritised recommendations</h3>
          <div className="recs">
            {plan.recommendations.map(r => (
              <article key={r.skillName} className="rec">
                <div className="rec-top">
                  <div><b>{r.skillName}</b><small>{r.category}</small></div>
                  <div className="rec-score"><Priority level={r.priority} /><span>{r.priorityScore}</span></div>
                </div>
                <div className="score-bar"><span style={{ width: `${r.priorityScore}%` }} /></div>
                <p className="why">{r.rationale}</p>
                <div className="rec-meta">
                  <span>Level {r.currentLevel} → {r.requiredLevel}</span>
                  <span>~{r.estimatedHours} h</span>
                </div>
                {r.courses.map(c => (
                  <div className="course" key={c.title}>
                    <Icon name="book" size={14} />
                    <div><b>{c.title}</b><small>{c.format} · {c.durationHours} h · levels {c.fromLevel}→{c.toLevel}</small></div>
                  </div>
                ))}
                {r.resource && <a className="resource" href={r.resource} target="_blank" rel="noreferrer">Official docs ↗</a>}
              </article>
            ))}
          </div>

          <h3>Week-by-week schedule <small className="muted">at {plan.hoursPerWeek} h/week</small></h3>
          <div className="weeks">
            {weeks.map(w => (
              <div className="week" key={w.week}>
                <div className="week-num">Week {w.week}<small>{w.hours} h</small></div>
                <ul>{w.items.map((it, i) => <li key={i}><b>{it.skillName}</b> {it.course} <small>{it.hours} h</small></li>)}</ul>
              </div>
            ))}
          </div>
          {plan.weeklyPlan.length > 6 && (
            <button className="btn ghost sm mt" onClick={() => setShowAllWeeks(v => !v)}>
              {showAllWeeks ? 'Show fewer weeks' : `Show all ${plan.weeklyPlan.length} weeks`}
            </button>
          )}
        </>
      )}
    </div>
  )
}
