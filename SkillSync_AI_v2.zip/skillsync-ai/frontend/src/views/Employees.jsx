import { useEffect, useMemo, useState } from 'react'
import { api } from '../api.js'
import { Avatar, Bar, Empty, Icon, Skeleton, useToast } from '../components/ui.jsx'

const SORTS = {
  readiness: { label: 'Readiness (low → high)', fn: (a, b) => a.readiness - b.readiness },
  name: { label: 'Name (A → Z)', fn: (a, b) => a.name.localeCompare(b.name) },
  gaps: { label: 'Most gaps', fn: (a, b) => b.gapCount - a.gapCount || b.criticalGaps - a.criticalGaps },
}

export default function Employees({ navigate, refreshKey, onAddEmployee }) {
  const toast = useToast()
  const [list, setList] = useState(null)
  const [search, setSearch] = useState('')
  const [dept, setDept] = useState('')
  const [sort, setSort] = useState('readiness')

  useEffect(() => {
    api.employees().then(setList).catch(err => { toast(err.message, 'error'); setList([]) })
  }, [refreshKey, toast])

  const departments = useMemo(() => [...new Set((list || []).map(e => e.department))].sort(), [list])
  const shown = useMemo(() => {
    const q = search.trim().toLowerCase()
    return (list || [])
      .filter(e => !dept || e.department === dept)
      .filter(e => !q || e.name.toLowerCase().includes(q) || e.jobRole.toLowerCase().includes(q) || e.topGaps.some(g => g.toLowerCase().includes(q)))
      .sort(SORTS[sort].fn)
  }, [list, search, dept, sort])

  return (
    <div className="panel">
      <div className="toolbar">
        <div className="search">
          <Icon name="search" size={16} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, role or gap skill" aria-label="Search employees" />
        </div>
        <select value={dept} onChange={e => setDept(e.target.value)} aria-label="Filter by department">
          <option value="">All departments</option>
          {departments.map(d => <option key={d}>{d}</option>)}
        </select>
        <select value={sort} onChange={e => setSort(e.target.value)} aria-label="Sort">
          {Object.entries(SORTS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <button className="btn primary" onClick={onAddEmployee}><Icon name="plus" /> Add employee</button>
      </div>

      {!list ? (
        <div className="cards">{[0, 1, 2, 3, 4, 5].map(i => <div className="card" key={i}><Skeleton h={90} /></div>)}</div>
      ) : shown.length ? (
        <div className="cards">
          {shown.map(e => (
            <button key={e.id} className="card emp" onClick={() => navigate(`/employees/${e.id}`)}>
              <div className="emp-top">
                <Avatar name={e.name} size={42} />
                <div className="grow">
                  <b>{e.name}</b>
                  <small>{e.jobRole}</small>
                </div>
                <span className="dept-chip">{e.department}</span>
              </div>
              <div className="emp-score">
                <span>Readiness</span><b>{e.readiness}%</b>
              </div>
              <Bar value={e.readiness} />
              <div className="emp-meta">
                <span>{e.skillCount} skills</span>
                <span className={e.gapCount ? 'warn-text' : 'good-text'}>{e.gapCount} gaps</span>
                {e.criticalGaps > 0 && <span className="bad-text">{e.criticalGaps} critical</span>}
              </div>
              {e.topGaps.length > 0 && <div className="tags">{e.topGaps.map(g => <span key={g}>{g}</span>)}</div>}
            </button>
          ))}
        </div>
      ) : (
        <Empty title={list.length ? 'No matches' : 'No employees yet'} icon="people">
          {list.length ? 'Try a different search or filter.' : 'Add an employee or import a CSV from the Skill matrix page.'}
        </Empty>
      )}
    </div>
  )
}
