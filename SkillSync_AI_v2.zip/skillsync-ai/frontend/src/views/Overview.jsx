import { Bar as RBar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Avatar, Bar, Empty, Icon, ReadinessRing, Skeleton, Stat } from '../components/ui.jsx'

export default function Overview({ dashboard, loading, navigate, onAddEmployee, colors }) {
  if (loading && !dashboard) return <OverviewSkeleton />
  const d = dashboard || { employees: 0, skillsTracked: 0, skillGaps: 0, criticalGaps: 0, readiness: 0, skillBreakdown: [], departments: [], needsAttention: [] }

  if (!d.employees) {
    return (
      <div className="panel">
        <Empty title="No employees yet" icon="people">
          Add your first employee or import a CSV to see team readiness, gaps and AI learning paths.
          <br /><button className="btn primary mt" onClick={onAddEmployee}><Icon name="plus" /> Add employee</button>
        </Empty>
      </div>
    )
  }

  const chart = d.skillBreakdown.map(s => ({ skill: s.skillName, Current: s.avgCurrent, Required: s.avgRequired, gap: s.avgGap, people: s.peopleWithGap }))

  return (
    <>
      <section className="stats">
        <Stat label="Employees" value={d.employees} note={`${d.departments.length} departments`} icon="people" />
        <Stat label="Assessments" value={d.skillsTracked} note={`${d.skillBreakdown.length} distinct skills`} icon="book" />
        <Stat label="Open gaps" value={d.skillGaps} note={`${Math.round((d.skillGaps / Math.max(1, d.skillsTracked)) * 100)}% of assessments`} icon="warning" tone="warn" />
        <Stat label="Critical gaps" value={d.criticalGaps} note="3+ levels below target" icon="warning" tone="bad" />
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-head">
            <div><h2>Team skill gaps</h2><p>Average current level vs. what roles require, widest gaps first</p></div>
          </div>
          <div className="chart">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chart} barGap={4} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={colors.line} />
                <XAxis dataKey="skill" tick={{ fontSize: 11, fill: colors.muted }} interval={0} angle={-20} textAnchor="end" height={54} />
                <YAxis domain={[0, 5]} ticks={[0, 1, 2, 3, 4, 5]} tick={{ fontSize: 11, fill: colors.muted }} />
                <Tooltip content={<GapTooltip />} cursor={{ fill: colors.hover }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <RBar dataKey="Current" fill={colors.accent} radius={[4, 4, 0, 0]} />
                <RBar dataKey="Required" fill={colors.accentSoft} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="panel center">
          <div className="panel-head left"><div><h2>Team readiness</h2><p>Share of required proficiency already in place</p></div></div>
          <ReadinessRing value={d.readiness} />
          <p className="caption">Readiness = Σ min(current, required) ÷ Σ required. Exceeding one target never hides a gap elsewhere.</p>
          <button className="btn primary full" onClick={() => navigate('/insights')}><Icon name="spark" /> Generate team AI insights</button>
        </div>
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-head"><div><h2>Needs attention</h2><p>Lowest readiness first</p></div>
            <button className="btn ghost sm" onClick={() => navigate('/employees')}>View all</button></div>
          {d.needsAttention.length ? (
            <ul className="list">
              {d.needsAttention.map(e => (
                <li key={e.id}>
                  <button className="row-link" onClick={() => navigate(`/employees/${e.id}`)}>
                    <Avatar name={e.name} />
                    <div className="grow">
                      <b>{e.name}</b>
                      <small>{e.jobRole} · gaps in {e.topGaps.join(', ')}</small>
                    </div>
                    <div className="mini-score">
                      <span>{e.readiness}%</span>
                      <Bar value={e.readiness} />
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          ) : <Empty title="Everyone is on target" icon="check" />}
        </div>

        <div className="panel">
          <div className="panel-head"><div><h2>Readiness by department</h2><p>Where to focus training budget</p></div></div>
          <ul className="dept">
            {d.departments.map(dep => (
              <li key={dep.department}>
                <div className="dept-top"><b>{dep.department}</b><span>{dep.readiness}%</span></div>
                <Bar value={dep.readiness} />
                <small>{dep.employees} people · {dep.gaps} open gaps</small>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  )
}

function GapTooltip({ active, payload }) {
  if (!active || !payload?.length) return null
  const p = payload[0].payload
  return (
    <div className="tip">
      <b>{p.skill}</b>
      <span>Current avg {p.Current} · Required avg {p.Required}</span>
      <span>{p.people} {p.people === 1 ? 'person' : 'people'} below target</span>
    </div>
  )
}

function OverviewSkeleton() {
  return (
    <>
      <section className="stats">{[0, 1, 2, 3].map(i => <div className="stat" key={i}><Skeleton w="50%" /><Skeleton h={30} w="40%" /><Skeleton w="70%" h={12} /></div>)}</section>
      <section className="grid-2"><div className="panel"><Skeleton h={320} /></div><div className="panel"><Skeleton h={320} /></div></section>
    </>
  )
}
