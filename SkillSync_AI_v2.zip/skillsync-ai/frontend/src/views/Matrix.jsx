import { useEffect, useMemo, useRef, useState } from 'react'
import { api, LEVELS } from '../api.js'
import { Confirm, Empty, Icon, Skeleton, useToast } from '../components/ui.jsx'

export default function Matrix({ navigate, refreshKey, onChanged }) {
  const toast = useToast()
  const [data, setData] = useState(null)
  const [dept, setDept] = useState('')
  const [mode, setMode] = useState('gap')
  const [importResult, setImportResult] = useState(null)
  const [confirmReset, setConfirmReset] = useState(false)
  const fileRef = useRef(null)

  useEffect(() => {
    api.matrix().then(setData).catch(err => { toast(err.message, 'error'); setData({ skills: [], rows: [] }) })
  }, [refreshKey, toast])

  const rows = useMemo(() => (data?.rows || []).filter(r => !dept || r.department === dept), [data, dept])
  const departments = useMemo(() => [...new Set((data?.rows || []).map(r => r.department))].sort(), [data])
  const skills = useMemo(() => (data?.skills || []).filter(s => rows.some(r => r.cells[s])), [data, rows])

  const columnStats = useMemo(() => Object.fromEntries(skills.map(s => {
    const cells = rows.map(r => r.cells[s]).filter(Boolean)
    return [s, { gaps: cells.filter(c => c.gap > 0).length, experts: cells.filter(c => c.current >= 4).length }]
  })), [skills, rows])

  async function download() {
    try {
      const res = await api.exportCsv()
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = Object.assign(document.createElement('a'), { href: url, download: `skillsync-export-${new Date().toISOString().slice(0, 10)}.csv` })
      a.click()
      URL.revokeObjectURL(url)
      toast('CSV exported')
    } catch (err) { toast(err.message, 'error') }
  }

  async function upload(e) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    try {
      const result = await api.importCsv(file)
      setImportResult(result)
      toast(`Imported: ${result.skillsCreated} new, ${result.skillsUpdated} updated`)
      onChanged()
    } catch (err) { toast(err.message, 'error') }
  }

  return (
    <>
      <div className="panel">
        <div className="toolbar">
          <div className="segmented" role="tablist" aria-label="Colour cells by">
            <button role="tab" aria-selected={mode === 'gap'} className={mode === 'gap' ? 'active' : ''} onClick={() => setMode('gap')}>Gap</button>
            <button role="tab" aria-selected={mode === 'level'} className={mode === 'level' ? 'active' : ''} onClick={() => setMode('level')}>Proficiency</button>
          </div>
          <select value={dept} onChange={e => setDept(e.target.value)} aria-label="Filter by department">
            <option value="">All departments</option>
            {departments.map(d => <option key={d}>{d}</option>)}
          </select>
          <div className="spacer" />
          <button className="btn ghost sm" onClick={download}><Icon name="download" size={15} /> Export CSV</button>
          <button className="btn ghost sm" onClick={() => fileRef.current?.click()}><Icon name="upload" size={15} /> Import CSV</button>
          <input ref={fileRef} type="file" accept=".csv,text/csv" hidden onChange={upload} />
          <button className="btn ghost sm" onClick={() => setConfirmReset(true)}><Icon name="refresh" size={15} /> Reset demo</button>
        </div>

        {importResult && (
          <div className={`import-result ${importResult.errors.length ? 'warn' : ''}`}>
            <b>Import complete:</b> {importResult.employeesCreated} employees created, {importResult.skillsCreated} skills added, {importResult.skillsUpdated} updated, {importResult.rowsSkipped} rows skipped.
            {importResult.errors.length > 0 && <ul>{importResult.errors.map(e => <li key={e}>{e}</li>)}</ul>}
            <button className="icon-btn" onClick={() => setImportResult(null)} aria-label="Dismiss"><Icon name="close" size={14} /></button>
          </div>
        )}

        {!data ? <Skeleton h={360} /> : rows.length ? (
          <div className="matrix-wrap">
            <table className="matrix">
              <thead>
                <tr>
                  <th className="sticky">Employee</th>
                  {skills.map(s => <th key={s}><span>{s}</span><small>{columnStats[s].gaps} gaps · {columnStats[s].experts} expert{columnStats[s].experts === 1 ? '' : 's'}</small></th>)}
                  <th>Ready</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.employeeId}>
                    <th className="sticky">
                      <button className="link" onClick={() => navigate(`/employees/${r.employeeId}`)}>{r.name}</button>
                      <small>{r.jobRole}</small>
                    </th>
                    {skills.map(s => {
                      const c = r.cells[s]
                      if (!c) return <td key={s} className="cell none" aria-label="Not required">·</td>
                      const cls = mode === 'gap' ? `g${Math.min(c.gap, 3)}` : `l${c.current}`
                      return (
                        <td key={s} className={`cell ${cls}`} title={`${r.name} · ${s}: ${LEVELS[c.current]} (${c.current}) → target ${c.required}`}>
                          {mode === 'gap' ? (c.gap > 0 ? `−${c.gap}` : '✓') : c.current}
                          <small>{c.current}/{c.required}</small>
                        </td>
                      )
                    })}
                    <td className="ready-cell"><b>{r.readiness}%</b></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <Empty title="Nothing to show" icon="grid">Add employees or import a CSV.</Empty>}

        <div className="legend-row">
          {mode === 'gap' ? <>
            <span><i className="cell g0" /> On target</span><span><i className="cell g1" /> 1 below</span>
            <span><i className="cell g2" /> 2 below</span><span><i className="cell g3" /> 3+ below (critical)</span>
          </> : [0, 1, 2, 3, 4, 5].map(l => <span key={l}><i className={`cell l${l}`} /> {l} {LEVELS[l]}</span>)}
          <span className="muted">CSV columns: employeeName, email, department, jobRole, skillName, currentLevel, requiredLevel</span>
        </div>
      </div>

      {confirmReset && (
        <Confirm title="Reset demo data?" message="This deletes all current employees and restores the 8-person demo team." confirmLabel="Reset"
          onClose={() => setConfirmReset(false)}
          onConfirm={async () => {
            try { await api.resetDemo(); toast('Demo data restored'); onChanged() }
            catch (err) { toast(err.message, 'error') }
            setConfirmReset(false)
          }} />
      )}
    </>
  )
}
