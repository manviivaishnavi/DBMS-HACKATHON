const BASE = (import.meta.env.VITE_API_URL || '/api').replace(/\/$/, '')

export class ApiError extends Error {
  constructor(message, status, fieldErrors) {
    super(message)
    this.status = status
    this.fieldErrors = fieldErrors || {}
  }
}

async function request(path, { method = 'GET', body, headers, raw } = {}) {
  let response
  try {
    response = await fetch(`${BASE}${path}`, {
      method,
      headers: body && !(body instanceof FormData) ? { 'Content-Type': 'application/json', ...headers } : headers,
      body: body instanceof FormData || typeof body === 'string' ? body : body ? JSON.stringify(body) : undefined,
    })
  } catch {
    throw new ApiError('Cannot reach the SkillSync API. Is the Spring Boot backend running on port 8080?', 0)
  }
  if (raw) {
    if (!response.ok) throw new ApiError(`Request failed (${response.status})`, response.status)
    return response
  }
  if (response.status === 204) return null
  const text = await response.text()
  let data = null
  try { data = text ? JSON.parse(text) : null } catch { data = null }
  if (!response.ok) {
    throw new ApiError(data?.message || `Request failed (${response.status})`, response.status, data?.fieldErrors)
  }
  return data
}

export const api = {
  health: () => request('/health'),
  dashboard: () => request('/dashboard'),
  matrix: () => request('/matrix'),
  roles: () => request('/roles'),

  employees: (params = {}) => {
    const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v)).toString()
    return request(`/employees${q ? `?${q}` : ''}`)
  },
  employee: (id) => request(`/employees/${id}`),
  createEmployee: (body) => request('/employees', { method: 'POST', body }),
  updateEmployee: (id, body) => request(`/employees/${id}`, { method: 'PUT', body }),
  deleteEmployee: (id) => request(`/employees/${id}`, { method: 'DELETE' }),

  addSkill: (employeeId, body) => request(`/employees/${employeeId}/skills`, { method: 'POST', body }),
  updateSkill: (id, body) => request(`/skills/${id}`, { method: 'PUT', body }),
  deleteSkill: (id) => request(`/skills/${id}`, { method: 'DELETE' }),

  recommendations: (employeeId, hoursPerWeek = 6) =>
    request(`/employees/${employeeId}/recommendations?hoursPerWeek=${hoursPerWeek}`, { method: 'POST' }),
  teamInsights: () => request('/insights/team', { method: 'POST' }),

  exportCsv: () => request('/export/csv', { raw: true }),
  importCsv: (file) => {
    const form = new FormData()
    form.append('file', file)
    return request('/import/csv', { method: 'POST', body: form })
  },
  resetDemo: () => request('/demo/reset', { method: 'POST' }),
}

export const LEVELS = ['None', 'Awareness', 'Beginner', 'Practitioner', 'Advanced', 'Expert']
