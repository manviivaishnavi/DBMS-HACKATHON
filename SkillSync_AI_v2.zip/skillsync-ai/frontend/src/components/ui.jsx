import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { LEVELS } from '../api.js'

/* ---------------------------------------------------------------- Icons */
const paths = {
  overview: 'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z',
  people: 'M16 11c1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 3-1.34 3-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5C15 14.17 10.33 13 8 13zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z',
  grid: 'M3 3h5v5H3zm6.5 0h5v5h-5zM16 3h5v5h-5zM3 9.5h5v5H3zm6.5 0h5v5h-5zm6.5 0h5v5h-5zM3 16h5v5H3zm6.5 0h5v5h-5zm6.5 0h5v5h-5z',
  spark: 'M12 2l2.4 6.9L21 12l-6.6 3.1L12 22l-2.4-6.9L3 12l6.6-3.1z',
  plus: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
  close: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
  edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 000-1.41l-2.34-2.34a1 1 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
  trash: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
  search: 'M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
  download: 'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z',
  upload: 'M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z',
  sun: 'M12 7a5 5 0 100 10 5 5 0 000-10zM2 13h2v-2H2v2zm18 0h2v-2h-2v2zM11 2v2h2V2h-2zm0 18v2h2v-2h-2zM5.99 4.58L4.58 5.99l1.41 1.41 1.41-1.41-1.41-1.41zm12.02 12.02l-1.41 1.41 1.41 1.41 1.41-1.41-1.41-1.41zM19.42 5.99l-1.41-1.41-1.41 1.41 1.41 1.41 1.41-1.41zM7.4 18.01l-1.41-1.41-1.41 1.41 1.41 1.41 1.41-1.41z',
  moon: 'M12 3a9 9 0 109 9c0-.46-.04-.92-.1-1.36a5.39 5.39 0 01-4.4 2.26 5.4 5.4 0 01-3.14-9.8c-.44-.06-.9-.1-1.36-.1z',
  back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
  mentor: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z',
  warning: 'M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z',
  book: 'M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z',
  refresh: 'M17.65 6.35A7.96 7.96 0 0012 4a8 8 0 108 8h-2a6 6 0 11-1.76-4.24L13 11h7V4l-2.35 2.35z',
  check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
  menu: 'M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z',
}
export function Icon({ name, size = 18, className = '' }) {
  return (
    <svg className={`icon ${className}`} width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <path d={paths[name]} fill="currentColor" />
    </svg>
  )
}

/* ---------------------------------------------------------------- Toasts */
const ToastCtx = createContext(() => {})
export const useToast = () => useContext(ToastCtx)

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])
  const push = useCallback((message, type = 'success') => {
    const id = Math.random().toString(36).slice(2)
    setToasts(t => [...t, { id, message, type }])
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), type === 'error' ? 6000 : 3200)
  }, [])
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {toasts.map(t => (
          <div key={t.id} className={`toast ${t.type}`}>
            <Icon name={t.type === 'error' ? 'warning' : 'check'} size={16} />
            <span>{t.message}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}

/* ---------------------------------------------------------------- Modal */
export function Modal({ title, subtitle, onClose, children, width = 520 }) {
  const ref = useRef(null)
  useEffect(() => {
    const onKey = e => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    ref.current?.querySelector('input, select, textarea, button')?.focus()
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])
  return (
    <div className="overlay" onMouseDown={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: width }} role="dialog" aria-modal="true" aria-label={title} ref={ref}>
        <div className="modal-head">
          <div>
            <h2>{title}</h2>
            {subtitle && <p>{subtitle}</p>}
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close"><Icon name="close" /></button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function Confirm({ title, message, confirmLabel = 'Delete', onConfirm, onClose }) {
  const [busy, setBusy] = useState(false)
  return (
    <Modal title={title} onClose={onClose} width={420}>
      <p className="muted">{message}</p>
      <div className="modal-actions">
        <button className="btn ghost" onClick={onClose}>Cancel</button>
        <button className="btn danger" disabled={busy} onClick={async () => { setBusy(true); await onConfirm(); setBusy(false) }}>
          {busy ? 'Working…' : confirmLabel}
        </button>
      </div>
    </Modal>
  )
}

/* ---------------------------------------------------------------- Bits */
export function ReadinessRing({ value = 0, size = 150, label = 'READY' }) {
  const r = 42, c = 2 * Math.PI * r
  const tone = value >= 80 ? 'var(--good)' : value >= 60 ? 'var(--accent)' : value >= 40 ? 'var(--warn)' : 'var(--bad)'
  return (
    <div className="ring" style={{ width: size, height: size }} role="img" aria-label={`${value}% ready`}>
      <svg viewBox="0 0 100 100">
        <circle cx="50" cy="50" r={r} className="ring-track" />
        <circle cx="50" cy="50" r={r} className="ring-value" style={{ stroke: tone, strokeDasharray: c, strokeDashoffset: c * (1 - value / 100) }} />
      </svg>
      <div className="ring-label"><strong>{value}%</strong><small>{label}</small></div>
    </div>
  )
}

export function Bar({ value, max = 100, tone }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100))
  const color = tone || (pct >= 80 ? 'var(--good)' : pct >= 60 ? 'var(--accent)' : pct >= 40 ? 'var(--warn)' : 'var(--bad)')
  return <div className="bar" aria-hidden="true"><span style={{ width: `${pct}%`, background: color }} /></div>
}

export function Stat({ label, value, note, icon, tone }) {
  return (
    <div className="stat">
      <div className="stat-top"><span>{label}</span><i className={tone}><Icon name={icon} size={16} /></i></div>
      <strong>{value}</strong>
      <small>{note}</small>
    </div>
  )
}

export function Priority({ level }) {
  return <span className={`pill p-${String(level).toLowerCase()}`}>{level}</span>
}

export function GapBadge({ gap }) {
  if (gap <= 0) return <span className="pill ok">On target</span>
  return <span className={`pill ${gap >= 3 ? 'p-critical' : gap === 2 ? 'p-high' : 'p-medium'}`}>−{gap}</span>
}

export function LevelDots({ current, required }) {
  return (
    <span className="dots" aria-label={`Level ${current} of 5, target ${required}`} title={`${LEVELS[current]} → target ${LEVELS[required]}`}>
      {[1, 2, 3, 4, 5].map(i => (
        <i key={i} className={i <= current ? (i <= required ? 'on' : 'over') : i <= required ? 'need' : ''} />
      ))}
    </span>
  )
}

export function LevelPicker({ label, value, onChange, min = 0 }) {
  return (
    <fieldset className="level-picker">
      <legend>{label} <b>{value} · {LEVELS[value]}</b></legend>
      <div>
        {[0, 1, 2, 3, 4, 5].filter(l => l >= min).map(l => (
          <button type="button" key={l} className={l === Number(value) ? 'active' : ''} onClick={() => onChange(l)} aria-pressed={l === Number(value)}>
            {l}
          </button>
        ))}
      </div>
    </fieldset>
  )
}

export function Avatar({ name, size = 36 }) {
  const initials = name.split(/\s+/).map(p => p[0]).slice(0, 2).join('').toUpperCase()
  let hash = 0
  for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) % 360
  return (
    <span className="avatar" style={{ width: size, height: size, fontSize: size * 0.38, background: `hsl(${hash} 55% 55%)` }} aria-hidden="true">
      {initials}
    </span>
  )
}

export function Empty({ icon = 'spark', title, children }) {
  return (
    <div className="empty">
      <Icon name={icon} size={28} />
      <b>{title}</b>
      {children && <p>{children}</p>}
    </div>
  )
}

export function Skeleton({ h = 18, w = '100%', r = 8 }) {
  return <span className="skeleton" style={{ height: h, width: w, borderRadius: r }} />
}

export function SourceTag({ source }) {
  return source === 'llm'
    ? <span className="source llm" title="Narrative written by an LLM from the engine's numbers"><Icon name="spark" size={12} /> LLM narrative</span>
    : <span className="source" title="Narrative generated by the rule-based engine">Rule-based narrative</span>
}
