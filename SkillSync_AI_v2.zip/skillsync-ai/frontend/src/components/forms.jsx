import { useState } from 'react'
import { api } from '../api.js'
import { LevelPicker, Modal, useToast } from './ui.jsx'

const DEPARTMENTS = ['Engineering', 'Data', 'Platform', 'Product', 'Design', 'Operations']

export function EmployeeForm({ employee, roles, onClose, onSaved }) {
  const toast = useToast()
  const editing = Boolean(employee)
  const roleList = roles?.roles || []
  const [form, setForm] = useState({
    name: employee?.name || '',
    email: employee?.email || '',
    department: employee?.department || 'Engineering',
    jobRole: employee?.jobRole || roleList[0]?.role || 'Software Engineer',
    applyRoleTemplate: !editing,
  })
  const [errors, setErrors] = useState({})
  const [busy, setBusy] = useState(false)
  const template = roleList.find(r => r.role === form.jobRole)
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  async function submit(e) {
    e.preventDefault()
    setBusy(true); setErrors({})
    try {
      const saved = editing ? await api.updateEmployee(employee.id, form) : await api.createEmployee(form)
      toast(editing ? 'Employee updated' : `${saved.name} added${form.applyRoleTemplate && template ? ` with ${saved.skills.length} role skills` : ''}`)
      onSaved(saved)
    } catch (err) {
      setErrors(err.fieldErrors || {})
      toast(err.message, 'error')
    } finally { setBusy(false) }
  }

  return (
    <Modal title={editing ? 'Edit employee' : 'Add employee'} subtitle={editing ? employee.name : 'Create a profile and optionally apply the role\'s skill template'} onClose={onClose}>
      <form className="form" onSubmit={submit}>
        <label>Full name
          <input required maxLength={100} value={form.name} onChange={e => set('name', e.target.value)} placeholder="e.g. Aarav Sharma" aria-invalid={!!errors.name} />
          {errors.name && <em>{errors.name}</em>}
        </label>
        <label>Work email <span className="opt">optional</span>
          <input type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="name@company.com" aria-invalid={!!errors.email} />
          {errors.email && <em>{errors.email}</em>}
        </label>
        <div className="two">
          <label>Department
            <input list="departments" value={form.department} onChange={e => set('department', e.target.value)} />
            <datalist id="departments">{DEPARTMENTS.map(d => <option key={d} value={d} />)}</datalist>
          </label>
          <label>Job role
            <input list="roles" required value={form.jobRole} onChange={e => set('jobRole', e.target.value)} />
            <datalist id="roles">{roleList.map(r => <option key={r.role} value={r.role} />)}</datalist>
          </label>
        </div>
        {!editing && (
          <div className={`template ${template ? '' : 'muted-box'}`}>
            <label className="check">
              <input type="checkbox" checked={form.applyRoleTemplate} disabled={!template} onChange={e => set('applyRoleTemplate', e.target.checked)} />
              <span>Apply role template</span>
            </label>
            {template
              ? <p>{template.description}. Adds {Object.entries(template.requiredSkills).map(([s, l]) => `${s} (${l})`).join(', ')} at level 0, ready for you to rate.</p>
              : <p>No template for this role. You can add skills one by one after saving.</p>}
          </div>
        )}
        <div className="modal-actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn primary" disabled={busy}>{busy ? 'Saving…' : editing ? 'Save changes' : 'Add employee'}</button>
        </div>
      </form>
    </Modal>
  )
}

export function SkillForm({ employeeId, skill, knownSkills = [], existing = [], onClose, onSaved }) {
  const toast = useToast()
  const editing = Boolean(skill)
  const [form, setForm] = useState({
    skillName: skill?.skillName || '',
    currentLevel: skill?.currentLevel ?? 1,
    requiredLevel: skill?.requiredLevel ?? 4,
  })
  const [busy, setBusy] = useState(false)
  const suggestions = knownSkills.filter(s => !existing.some(e => e.toLowerCase() === s.toLowerCase()) || s === skill?.skillName)

  async function submit(e) {
    e.preventDefault()
    setBusy(true)
    try {
      const saved = editing ? await api.updateSkill(skill.id, form) : await api.addSkill(employeeId, form)
      toast(editing ? `${saved.skillName} updated` : `${saved.skillName} added`)
      onSaved(saved)
    } catch (err) {
      toast(err.message, 'error')
    } finally { setBusy(false) }
  }

  const gap = form.requiredLevel - form.currentLevel
  return (
    <Modal title={editing ? 'Update assessment' : 'Add skill'} subtitle="Rate current proficiency against what the role needs" onClose={onClose}>
      <form className="form" onSubmit={submit}>
        <label>Skill
          <input list="skills" required maxLength={60} value={form.skillName} onChange={e => setForm({ ...form, skillName: e.target.value })} placeholder="Pick or type a skill" />
          <datalist id="skills">{suggestions.map(s => <option key={s} value={s} />)}</datalist>
        </label>
        <LevelPicker label="Current level" value={form.currentLevel} onChange={v => setForm({ ...form, currentLevel: v })} />
        <LevelPicker label="Required level" min={1} value={form.requiredLevel} onChange={v => setForm({ ...form, requiredLevel: v })} />
        <div className={`gap-preview ${gap >= 3 ? 'bad' : gap > 0 ? 'warn' : 'good'}`}>
          {gap > 0 ? `Gap of ${gap} level${gap > 1 ? 's' : ''}${gap >= 3 ? ' · critical' : ''}` : 'Meets or exceeds target'}
        </div>
        <div className="modal-actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn primary" disabled={busy}>{busy ? 'Saving…' : editing ? 'Save' : 'Add skill'}</button>
        </div>
      </form>
    </Modal>
  )
}
