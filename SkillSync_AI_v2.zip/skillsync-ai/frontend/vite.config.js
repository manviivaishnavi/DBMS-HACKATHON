import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// In dev, /api is proxied to Spring Boot so the browser never hits CORS.
// Override the target with VITE_BACKEND_URL if your backend runs elsewhere.
export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: { output: { manualChunks: { charts: ['recharts'] } } },
  },
  server: {
    port: 5173,
    proxy: {
      '/api': { target: process.env.VITE_BACKEND_URL || 'http://localhost:8080', changeOrigin: true },
    },
  },
  preview: {
    port: 4173,
    proxy: {
      '/api': { target: process.env.VITE_BACKEND_URL || 'http://localhost:8080', changeOrigin: true },
    },
  },
})
